import { defineConfig } from "@playwright/test";
import { defineBddConfig } from "playwright-bdd";
import { browserSettings } from "./utils/ui/BrowserConfigUtil.js";
import dotenv from "dotenv";

dotenv.config({ path: "./environments.env" });
dotenv.config({ path: "./steps/config.env" });

const timestamp = new Date().toISOString().replace(/[:.]/g, "-");

const bddExtension = defineBddConfig({
  features: "features/**/*.feature",
  steps: "steps/**/*.ts",
  tags: process.env.TAGS || "@enroll",
  importTestFrom: "./steps/fixtures.ts",
  disableWarnings: {
    importTestFrom: true,
  },
});

export default defineConfig({
  testDir: bddExtension,
  ...(process.env.CI ? { workers: 2, retries: 2 } : { retries: 0 }),
  fullyParallel: true,
  timeout: 1200000, // Controls the maximum time allowed for the entire test to complete.
  reporter: [
    [
      "html",
      {
        outputFolder: `./test-results/html-report/run_${timestamp}`,
        open: "always",
      },
    ],
    [
      "junit",
      { outputFile: `./test-results/xmlresults/xmlresults_${timestamp}.xml` },
    ],
    ["allure-playwright", { outputFolder: "./test-results/allure-results" }],
  ],
  outputDir: `./test-results/traceartifacts/run_${timestamp}`,
  use: {
    ...browserSettings,
    trace: "retain-on-failure",
    actionTimeout: 30000, // Controls the maximum time for a single Playwright action.
    //storageState: './storage/auth.json'
  },
});
