import dotenv from 'dotenv';

export async function getconfigdata(){

}