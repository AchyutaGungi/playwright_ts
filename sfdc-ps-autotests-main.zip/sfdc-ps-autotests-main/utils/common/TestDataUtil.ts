import fs from 'fs';
import path from 'path';

export let testData: Record<string, string> = {};

export function loadAndSetTestData(environment: string, featureName: string, squadName: string): void {
    const filePath = path.join(process.cwd(), 'testdata',squadName,`${squadName}.json`);
    const allData = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
    const matchedKey = Object.keys(allData).find(
        key => key.toLowerCase() === featureName.toLowerCase()
    );
    if (!matchedKey) {
        throw new Error(`Feature "${featureName}" not found in test data`);
    }
    if (!allData[matchedKey][environment]) {
        throw new Error(`Environment "${environment}" not found for feature "${matchedKey}"`);
    }
    testData = allData[matchedKey][environment];
    //console.log(testData);
}

