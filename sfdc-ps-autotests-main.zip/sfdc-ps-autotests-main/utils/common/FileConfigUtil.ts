import fs from 'fs';
import path from 'path';

export class fileConfigUtil{

     private static filePath: string = '';

    /**
     * This method is used to create a new text file with current timestamp
     * @param directory
     * @returns filePath
     * @author SurendraKumarVetcha
     */
    static createRunTimeFile(directory: string = './results',filename:string): string {
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const fileName = filename+`_${timestamp}.txt`;
        this.filePath = path.join(directory, fileName);
        if (!fs.existsSync(directory)) {
            fs.mkdirSync(directory, { recursive: true });
        }
        fs.writeFileSync(this.filePath, '');
        console.log(`File created: ${this.filePath}`);
        return this.filePath;
    }

    /**
     * This method is used to insert a key-value pair into the store file
     * @param key, value
     * @author SurendraKumarVetcha
     */
    static insertData(key: string, value: string): void {
        const existingData = this.getAllData();
        existingData[key] = value;
        const content = Object.entries(existingData)
            .map(([k, v]) => `${k}=${v}`)
            .join('\n');
        fs.writeFileSync(this.filePath, content);
    }

    /**
     * This method is used to get all key-value pairs from the store file
     * 
     * @returns object containing all key-value pairs
     * @author SurendraKumarVetcha
     */
    static getAllData(): Record<string, string> {
        if (!this.filePath || !fs.existsSync(this.filePath)) {
            return {};
        }
        const content = fs.readFileSync(this.filePath, 'utf-8').trim();
        if (content.length === 0) return {};
        const data: Record<string, string> = {};
        content.split('\n').forEach(line => {
            const index = line.indexOf('=');
            if (index > 0) {
                data[line.substring(0, index)] = line.substring(index + 1);
            }
        });
        return data;
    }

    /**
     * This method is used to get a value from the store file by key
     * 
     * @param key
     * @returns value
     * @author SurendraKumarVetcha
     */
    static getData(key: string): string {
        const data = this.getAllData();
        if (!(key in data)) {
            throw new Error(`Key '${key}' not found in store`);
        }
        return data[key] as string;
    }
}