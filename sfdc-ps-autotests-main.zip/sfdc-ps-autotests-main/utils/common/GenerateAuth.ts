import { chromium } from '@playwright/test';
import dotenv from 'dotenv';

dotenv.config({ path: './steps/config.env' });

const usernametextbox = "#username";
const loginbutton = "#Login";
const passwordtextbox = "#password";

async function generateAuth() {
  const browser = await chromium.launch({
    headless: false
  });
  const context = await browser.newContext();
  const page = await context.newPage();
  await page.goto(process.env.LSCURL!);
  await page.locator(usernametextbox).fill(String(process.env['AutomationAdmin']));
  await page.locator(loginbutton).click();
  await page.locator(passwordtextbox).fill(String(process.env['AutomationAdminPassword']));
  await page.locator(loginbutton).click();
  await page.waitForLoadState();
  await page.pause();
  await context.storageState({
    path: './storage/auth.json'
  });
  await browser.close();
}

generateAuth();