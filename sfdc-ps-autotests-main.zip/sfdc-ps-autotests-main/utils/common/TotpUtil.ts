import { authenticator } from 'otplib';

export class TotpUtil {
    public static generateOtp(user: string): string {

        const secret = process.env[`${user}_TOTP_SECRET`];

        if (!secret) {
            throw new Error(`TOTP secret not found for ${user}`);
        }

        return authenticator.generate(secret);
    }
}
