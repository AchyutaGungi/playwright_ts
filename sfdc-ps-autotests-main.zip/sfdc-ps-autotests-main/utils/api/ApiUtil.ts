import { APIRequestContext, APIResponse } from "@playwright/test";

export class ApiUtil {
  constructor(private request: APIRequestContext) {}

  async sendRequest({
    method,
    url,
    payload,
    authorization,
    headers,
    queryParams,
  }: {
    method: string;
    url: string;
    payload?: any;
    authorization?: string;
    headers?: Record<string, string>;
    queryParams?: Record<string, string | number | boolean>;
  }): Promise<APIResponse> {
    const requestOptions: any = {
      headers: {
        "Content-Type": "application/json",
        ...headers,
        ...(authorization ? { Authorization: authorization } : {}),
      },
    };
    if (payload) {
      requestOptions.data = payload;
    }
    if (queryParams) {
      requestOptions.params = queryParams;
    }

    switch (method.toUpperCase()) {
      case "GET":
        return await this.request.get(url, requestOptions);
      case "POST":
        return await this.request.post(url, requestOptions);
      case "PUT":
        return await this.request.put(url, requestOptions);
      case "PATCH":
        return await this.request.patch(url, requestOptions);
      case "DELETE":
        return await this.request.delete(url, requestOptions);
      default:
        throw new Error(`Unsupported request type: ${method}`);
    }
  }

  getBasicAuth(username: string, password: string): string {
    return `Basic ${Buffer.from(`${username}:${password}`).toString("base64")}`;
  }

  getBearerToken(token: string): string {
    return `Bearer ${token}`;
  }
}
