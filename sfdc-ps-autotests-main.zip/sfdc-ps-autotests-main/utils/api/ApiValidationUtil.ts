import { APIResponse, expect } from "@playwright/test";

export class ApiValidationUtil {
  static async validateStatusCode(response: APIResponse, expectedStatusCode: number) {
    expect(response.status()).toBe(expectedStatusCode);
  }

  static async validateField(response: APIResponse, fieldName: string, expectedValue: any) {
    const body = await response.json();
    const actualValue = fieldName.split(".").reduce((obj, key) => obj?.[key], body);
    expect(actualValue).toEqual(expectedValue);
  }

  static async validateFieldExists(response: APIResponse, fieldName: string) {
    const body = await response.json();
    expect(body[fieldName]).toBeDefined();
  }

  static async validateResponseContains(response: APIResponse, expectedObject: any) {
    const responseBody = await response.text();
    expect(responseBody).toContain(expectedObject);
  }

  static async validateResponseTime(startTime: number, maxResponseTime: number) {
    const actualResponseTime = Date.now() - startTime;
    expect(actualResponseTime).toBeLessThan(maxResponseTime);
  }
}
