import { expect, Page, Locator } from "@playwright/test";

/**
 * ActionEngineUtil contains reusable wrapper methods for common UI interactions
 * and validations across the automation framework.
 *
 * Benefits:
 * - Centralized UI actions
 * - Consistent validations
 * - Better reporting and maintainability
 * - Reduced code duplication
 */
export class ActionEngineUtil {
  constructor(private page: Page) {}

  /**
   * Clicks on an element after verifying it is visible.
   *
   * @param selector Element selector.
   * @param elementName Friendly element name for reporting.
   * @returns Promise<void>
   * @author Surendra V
   */
  async clickElement(selector: string, elementName: string): Promise<void> {
    const locator = this.page.locator(selector);
    await expect(locator, `${elementName} should be visible`).toBeVisible();
    await locator.click();
  }

  /**
   * Enters text into an input field.
   *
   * @param selector Element selector.
   * @param value Text value to enter.
   * @param elementName Friendly element name for reporting.
   * @returns Promise<void>
   * @author Surendra V
   */
  async enterText(selector: string, value: string, elementName: string): Promise<void> {
    const locator = this.page.locator(selector);
    await expect(locator, `${elementName} should be visible`).toBeVisible();
    await locator.fill(value);
  }

  /**
   * Clears existing text and enters new text.
   *
   * @param selector Element selector.
   * @param value Text value to enter.
   * @param elementName Friendly element name for reporting.
   * @returns Promise<void>
   * @author Surendra V
   */
  async clearAndEnterText(selector: string, value: string, elementName: string): Promise<void> {
    const locator = this.page.locator(selector);
    await expect(locator, `${elementName} should be visible`).toBeVisible();
    await locator.clear();
    await locator.fill(value);
  }

  /**
   * Verifies an element is visible.
   *
   * @param selector Element selector.
   * @param elementName Friendly element name for reporting.
   * @returns Promise<void>
   * @author Surendra V
   */
  async verifyElementVisible(selector: string, elementName: string): Promise<void> {
    await expect(this.page.locator(selector), `${elementName} should be visible`).toBeVisible();
  }

  /**
   * Verifies an element is hidden.
   *
   * @param selector Element selector.
   * @param elementName Friendly element name for reporting.
   * @returns Promise<void>
   * @author Surendra V
   */
  async verifyElementNotVisible(selector: string, elementName: string): Promise<void> {
    await expect(this.page.locator(selector), `${elementName} should not be visible`).toBeHidden();
  }

  /**
   * Verifies an element exists in DOM.
   *
   * @param selector Element selector.
   * @param elementName Friendly element name.
   * @returns Promise<void>
   * @author Surendra V
   */
  async verifyElementPresent(selector: string, elementName: string): Promise<void> {
    await expect(this.page.locator(selector), `${elementName} is not present`).toBeAttached();
  }

  /**
   * Checks if element exists in DOM.
   *
   * @param selector Element selector.
   * @returns Promise<boolean>
   * @author Surendra V
   */
  async isElementPresentDOM(selector: string): Promise<boolean> {
    return (await this.page.locator(selector).count()) > 0;
  }

  /**
   * Checks if element is visible.
   *
   * @param selector Element selector.
   * @returns Promise<boolean>
   * @author Surendra V
   */
  async isElementVisible(selector: string): Promise<boolean> {
    return await this.page.locator(selector).isVisible();
  }

  /**
   * Returns text from an element.
   *
   * @param selector Element selector.
   * @returns Promise<string>
   * @author Surendra V
   */
  async getText(selector: string): Promise<string> {
    return (await this.page.locator(selector).textContent())?.trim() ?? "";
  }

  /**
   * Waits for element to become visible.
   *
   * @param selector Element selector.
   * @param timeout Timeout in milliseconds.
   * @returns Promise<void>
   * @author Surendra V
   */
  async waitForElementVisible(selector: string, timeout: number = 30000): Promise<void> {
    await this.page.locator(selector).waitFor({
      state: "visible",
      timeout,
    });
  }

  /**
   * Waits for element to become hidden.
   *
   * @param selector Element selector.
   * @param timeout Timeout in milliseconds.
   * @returns Promise<void>
   * @author Surendra V
   */
  async waitForElementHidden(selector: string, timeout: number = 30000): Promise<void> {
    await this.page.locator(selector).waitFor({
      state: "hidden",
      timeout,
    });
  }

  /**
   * Selects dropdown value by visible text.
   *
   * @param selector Dropdown selector.
   * @param value Visible text.
   * @param elementName Friendly element name.
   * @returns Promise<void>
   * @author Surendra V
   */
  async selectByText(selector: string, value: string, elementName: string): Promise<void> {
    await expect(this.page.locator(selector), `${elementName} should be visible`).toBeVisible();

    await this.page.locator(selector).selectOption({ label: value });
  }

  /**
   * Selects dropdown value by option value.
   *
   * @param selector Dropdown selector.
   * @param value Option value.
   * @param elementName Friendly element name.
   * @returns Promise<void>
   * @author Surendra V
   */
  async selectByValue(selector: string, value: string, elementName: string): Promise<void> {
    await expect(this.page.locator(selector), `${elementName} should be visible`).toBeVisible();

    await this.page.locator(selector).selectOption(value);
  }

  /**
   * Checks a checkbox.
   *
   * @param selector Checkbox selector.
   * @param elementName Friendly element name.
   * @returns Promise<void>
   * @author Surendra V
   */
  async checkBox(selector: string, elementName: string): Promise<void> {
    const checkbox = this.page.locator(selector);

    await expect(checkbox, `${elementName} should be visible`).toBeVisible();

    await checkbox.check();
  }

  /**
   * Unchecks a checkbox.
   *
   * @param selector Checkbox selector.
   * @param elementName Friendly element name.
   * @returns Promise<void>
   * @author Surendra V
   */
  async unCheckBox(selector: string, elementName: string): Promise<void> {
    const checkbox = this.page.locator(selector);

    await expect(checkbox, `${elementName} should be visible`).toBeVisible();

    await checkbox.uncheck();
  }

  /**
   * Verifies element text.
   *
   * @param selector Element selector.
   * @param expectedText Expected text.
   * @param elementName Friendly element name.
   * @returns Promise<void>
   * @author Surendra V
   */
  async verifyText(selector: string, expectedText: string, elementName: string): Promise<void> {
    await expect(this.page.locator(selector), `${elementName} text validation failed`).toHaveText(expectedText);
  }

  /**
   * Returns attribute value.
   *
   * @param selector Element selector.
   * @param attributeName Attribute name.
   * @returns Promise<string | null>
   * @author Surendra V
   */
  async getAttributeValue(selector: string, attributeName: string): Promise<string | null> {
    return await this.page.locator(selector).getAttribute(attributeName);
  }

  /**
   * Hovers over an element.
   *
   * @param selector Element selector.
   * @param elementName Friendly element name.
   * @returns Promise<void>
   * @author Surendra V
   */
  async hoverElement(selector: string, elementName: string): Promise<void> {
    await expect(this.page.locator(selector), `${elementName} should be visible`).toBeVisible();

    await this.page.locator(selector).hover();
  }

  /**
   * Scrolls element into view.
   *
   * @param selector Element selector.
   * @returns Promise<void>
   * @author Surendra V
   */
  async scrollToElement(selector: string): Promise<void> {
    await this.page.locator(selector).scrollIntoViewIfNeeded();
  }

  /**
   * Performs JavaScript click.
   *
   * @param selector Element selector.
   * @returns Promise<void>
   * @author Surendra V
   */
  async jsClick(selector: string): Promise<void> {
    await this.page.locator(selector).evaluate((element) => (element as HTMLElement).click());
  }

  /**
   * Presses a keyboard key.
   *
   * @param key Keyboard key.
   * @returns Promise<void>
   * @author Surendra V
   */
  async pressKey(key: string): Promise<void> {
    await this.page.keyboard.press(key);
  }

  /**
   * Verifies URL.
   *
   * @param expectedUrl Expected URL.
   * @returns Promise<void>
   * @author Surendra V
   */
  async verifyUrl(expectedUrl: string): Promise<void> {
    await expect(this.page).toHaveURL(new RegExp(expectedUrl));
  }

  /**
   * Waits for loader/spinner to disappear.
   *
   * @param selector Loader selector.
   * @returns Promise<void>
   * @author Surendra V
   */
  async waitForLoaderToDisappear(selector: string): Promise<void> {
    await this.page.locator(selector).waitFor({ state: "hidden" });
  }

  /**
   * Verifies that the specified element locator is visible.
   * Useful for locators refined using `.first()` or `.filter()`.
   *
   * @param locator Playwright locator.
   * @param elementName element name.
   * @returns Promise<void>
   * @author Pavan Kumar
   */
  async verifyLocatorVisible(locator: Locator, elementName: string): Promise<void> {
    await expect(locator, `${elementName} should be visible`).toBeVisible();
  }

  /**
   * Clicks a Locator after verifying visibility.
   * Useful for locators refined using `.first()` or `.filter()`.
   *
   * @param locator Playwright locator.
   * @param elementName element name.
   * @author Pavan Kumar
   */
  async clickFilteredLocator(locator: Locator, elementName: string): Promise<void> {
    await expect(locator, `${elementName} should be visible`).toBeVisible();
    await locator.click();
  }

  /**
   * Verifies that the actual text contains the expected text
   *
   * @param locator Playwright locator.
   * @param elementName element name.
   * @author Supriya
   */
  async verifyContainsText(selector: string, expectedText: string, elementName: string): Promise<void> {
    await expect(this.page.locator(selector), `${elementName} text validation failed`).toContainText(expectedText);
  }

  /**
   * Verifies the attribute value of an element.
   *
   * @param locator
   * @param attribute
   * @param expectedValue
   * @param elementName
   * @returns {Promise<void>}
   * @author Pavan Kumar
   */
  public async verifyElementAttributeValue(
    locator: string,
    attribute: string,
    expectedValue: string,
    elementName: string
  ): Promise<void> {
    await expect(
      this.page.locator(locator),
      `${elementName} ${attribute} should be '${expectedValue}'`
    ).toHaveAttribute(attribute, expectedValue);
  }
  /**
   * This method scroll page to bottom
   *
   * @author Supriya
   */
  async scrollToBottom(): Promise<void> {
    await this.page.evaluate(() => {
      window.scrollTo(0, document.body.scrollHeight);
    });
  }
}
