const browserName = (process.env.BROWSER || "chromium") as "chromium" | "firefox" | "webkit";
const isHeadless = process.env.HEADLESS === "true";

export const browserSettings = {
  browserName: browserName,
  headless: isHeadless,
  ...(browserName === "chromium" && { channel: "chrome" as const }),
  launchOptions: {
    args: isHeadless
      ? ["--window-size=1300,680", "--disable-gpu", "--no-sandbox", "--disable-dev-shm-usage"]
      : ["--start-maximized", "--no-sandbox", "--disable-dev-shm-usage"],
  },
  ignoreHTTPSErrors: true,
  viewport: isHeadless ? { width: 1300, height: 680 } : (null as null),
  locale: "en-US",
  screenshot: "only-on-failure" as const,
  trace: "retain-on-failure" as const,
  video: "on-first-retry" as const,
};
