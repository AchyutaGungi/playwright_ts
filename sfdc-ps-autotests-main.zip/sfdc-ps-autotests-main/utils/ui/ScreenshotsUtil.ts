import { Page, TestInfo } from '@playwright/test';
import fs from 'fs';

/**
 * Captures a screenshot after execution of a test step and attaches it
 * to the Playwright HTML report based on framework configuration.
 *
 * Screenshot capture is performed only when the environment variable
 * SCREENSHOT_AFTER_STEP is set to 'true'.
 *
 * The screenshot is:
 * - Saved under the reports/screenshots directory.
 * - Named using the test title and current timestamp.
 * - Attached to the corresponding test step in the Playwright report.
 *
 * @param page Playwright Page instance used to capture the screenshot.
 * @param testInfo Playwright TestInfo object used for report attachments.
 * @param stepname Name of the executed step to be displayed in the report.
 * @author Surendra V
 */
export async function captureScreenshotafterstep(page: Page, testInfo: TestInfo, stepname: string ) {
  if (process.env.SCREENSHOT_AFTER_STEP !== 'true') return;
  const dir = './test-results/screenshots';
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  const timestamp = Date.now();
  const fileName = `${testInfo.title.replace(/\s+/g, '_')}_${timestamp}.png`;
  const screenshot = await page.screenshot({ path: `${dir}/${fileName}`, fullPage: true });
  await testInfo.attach(stepname+' Step Screenshot', {
    body: screenshot,
    contentType: 'image/png',
  });
}

/**
 * Captures screenshot on-demand and attaches it to Playwright HTML report.
 *
 * @param page Playwright page instance.
 * @param testInfo Playwright test info object.
 * @param screenshotName Screenshot name displayed in report.
 * @author Surendra V
 */
export async function captureEvidenceScreenshot(page: Page,testInfo: TestInfo,screenshotName: string) {
  if (process.env.SCREENSHOTCAPTURE_ENABLE !== 'true') return;
  const dir = './test-results/screenshots';
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  const timestamp = Date.now();
  const fileName = `${screenshotName.replace(/\s+/g, '_')}_${timestamp}.png`;
  const screenshot = await page.screenshot({
    path: `${dir}/${fileName}`,
    fullPage: true
  });
  await testInfo.attach(screenshotName, {
    body: screenshot,
    contentType: 'image/png'
  });
}