export class ScenarioContext {

    private contextData =
        new Map<string, any>();

    public set(
        key: string,
        value: any
    ) {
        this.contextData.set(
            key,
            value
        );
    }

    public get(
        key: string
    ) {
        return this.contextData.get(
            key
        );
    }
}