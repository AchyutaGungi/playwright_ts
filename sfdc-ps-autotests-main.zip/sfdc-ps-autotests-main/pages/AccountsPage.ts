import { testData } from "../utils/common/TestDataUtil.js";
import { Page, expect, TestInfo } from "@playwright/test";
import { fileConfigUtil } from "../utils/common/FileConfigUtil.js";
import { ActionEngineUtil } from "../utils/ui/ActionEngineUtil.js";
import { CommonPage } from "../pages/CommonPage.js";
import { captureEvidenceScreenshot } from "../utils/ui/ScreenshotsUtil.js";

const patientRecordHeaderDynXpath: string = "//h1//lightning-formatted-name[normalize-space()='%s']";
const accountFieldValueDynXpath = "//*[@field-label='%s']//*[@slot='outputField']";
const accountCheckboxIconDynXpath: string = "//*[@field-label='%s']//lightning-icon";
const accountRecordTypeFieldValueXpath: string =
  "//*[@field-label='Account Record Type']//*[@slot='outputField']//span";
const relatedListViewAllDynXpath: string = "//a[contains(@aria-label,'View All %s')]";
const relatedListTitleDynXpath: string = "//h2//*[@title='%s']";
const tableRowsDynXpath: string = "//table[@aria-label='%s']//tbody//tr";
const tableHeaderCellXpath: string = "th";
const tableCellsXpath: string = "td";
const relatedListTableHeaderDynXpath: string = "//table[@aria-label='%s']//thead//th";

export class AccountsPage {
  private page: Page;
  private actionEngine: ActionEngineUtil;
  private testInfo: TestInfo;
  private commonPage: CommonPage;
  /**
   * This constructor is used to initialize the AccountPage with page
   * @param page
   * @author SurendraKumarVetcha
   */
  constructor(page: Page, testInfo: TestInfo) {
    this.page = page;
    this.actionEngine = new ActionEngineUtil(this.page);
    this.testInfo = testInfo;
    this.commonPage = new CommonPage(this.page, testInfo);
  }

  /**
   * Searches for the enrolled patient record using the patient's
   * First Name and Last Name from test data and opens the record.
   *
   * @returns {Promise<void>}
   * @author Pavan Kumar
   */
  public async searchAndOpenEnrolledPatientRecord(): Promise<void> {
    const patientName = `${fileConfigUtil.getData("FirstName")} ${fileConfigUtil.getData("LastName")}`;
    await this.commonPage.searchAndSelectRecord(patientName);
  }

  /**
   * Verifies that the enrolled patient record is opened.
   *
   * @returns {Promise<void>}
   * @author Pavan Kumar
   */
  public async verifyEnrolledPatientRecordIsOpened(): Promise<void> {
    const patientName = `${fileConfigUtil.getData("FirstName")} ${fileConfigUtil.getData("LastName")}`;
    await this.actionEngine.verifyElementVisible(
      patientRecordHeaderDynXpath.replace("%s", patientName),
      "Patient Name"
    );
  }

  /**
   * Verifies account field values.
   *
   * @param fieldMappings
   * @returns {Promise<void>}
   * @author Pavan Kumar
   */
  private async verifyAccountFields(fieldMappings: Record<string, string>): Promise<void> {
    for (const [fieldLabel, expectedValue] of Object.entries(fieldMappings)) {
      await this.actionEngine.verifyText(
        accountFieldValueDynXpath.replace("%s", fieldLabel),
        expectedValue,
        fieldLabel
      );
    }
  }

  /**
   * Verifies checkbox state using title attribute.
   *
   * @param fieldLabel
   * @param expectedValue
   * @returns {Promise<void>}
   * @author Pavan Kumar
   */
  private async verifyCheckboxField(fieldLabel: string, expectedValue: string): Promise<void> {
    await this.actionEngine.verifyElementAttributeValue(
      accountCheckboxIconDynXpath.replace("%s", fieldLabel),
      "title",
      expectedValue,
      fieldLabel
    );
  }

  /**
   * Verifies Account Record Type.
   *
   * @param expectedRecordType
   * @returns {Promise<void>}
   * @author Pavan Kumar
   */
  private async verifyAccountRecordType(expectedRecordType: string): Promise<void> {
    await expect(this.page.locator(accountRecordTypeFieldValueXpath).first()).toHaveText(expectedRecordType);
  }

  /****
   * Verifies Financial Eligibility details against the enrolled patient data.
   *
   * @returns {Promise<void>}
   * @author Pavan Kumar
   */
  public async verifyFinancialEligibilityDetails(): Promise<void> {
    const annualHouseholdIncome = Number(fileConfigUtil.getData("AnnualHouseholdIncome")).toLocaleString("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 2,
    });
    const fieldMappings: Record<string, string> = {
      "Household Size": fileConfigUtil.getData("HouseholdSize"),
      "Annual Household Income": annualHouseholdIncome,
    };
    await this.verifyAccountFields(fieldMappings);
  }

  /**
   * Verifies patient details against the enrolled patient data.
   *
   * @returns {Promise<void>}
   * @author Pavan Kumar
   */
  public async verifyPatientDetailsAgainstEnrolledPatientData(): Promise<void> {
    const patientInfo = testData.PATIENTINFORMATIONDATA as unknown as Record<string, string>;
    const accountName = `${fileConfigUtil.getData("FirstName")} ${fileConfigUtil.getData("LastName")}`;
    const birthDate = fileConfigUtil.getData("DOB")?.replace(/^0?(\d+)\/0?(\d+)\/(\d+)$/, "$1/$2/$3") ?? "";
    const householdSize = fileConfigUtil.getData("HouseholdSize") ?? "";
    const income = fileConfigUtil.getData("AnnualHouseholdIncome");
    const annualHouseholdIncome = income
      ? Number(income).toLocaleString("en-US", {
          style: "currency",
          currency: "USD",
          minimumFractionDigits: 2,
        })
      : "";
    const genderIdentity = patientInfo["Gender"] ?? "";
    const preferredLanguage = patientInfo["Preferred Language"] ?? "";
    const doNotContactPatient =
      (patientInfo["Do Not Contact Patient"] ?? "").toLowerCase() === "yes" ? "True" : "False";
    const fieldMappings: Record<string, string> = {
      "Account Name": accountName,
      Birthdate: birthDate,
      "Gender Identity": genderIdentity,
      "Preferred Language": preferredLanguage,
      "Household Size": householdSize,
      "Annual Household Income": annualHouseholdIncome,
    };
    await this.verifyAccountFields(fieldMappings);
    await this.verifyAccountRecordType("Patient");
    await this.verifyCheckboxField("Do Not Contact Patient", doNotContactPatient);
  }

  /**
   * Verifies patient details against the enrolled patient data.
   *
   * @returns {Promise<void>}
   * @author Pavan Kumar
   */
  public async verifyPatientDetailsExceptHouseholdSizeAndAnnualIncome(): Promise<void> {
    const patientInfo = testData.PATIENTINFORMATIONDATA as unknown as Record<string, string>;
    const accountName = `${fileConfigUtil.getData("FirstName")} ${fileConfigUtil.getData("LastName")}`;
    const birthDate = fileConfigUtil.getData("DOB")?.replace(/^0?(\d+)\/0?(\d+)\/(\d+)$/, "$1/$2/$3") ?? "";
    const genderIdentity = patientInfo["Gender"] ?? "";
    const preferredLanguage = patientInfo["Preferred Language"] ?? "";
    const doNotContactPatient =
      (patientInfo["Do Not Contact Patient"] ?? "").toLowerCase() === "yes" ? "True" : "False";
    const fieldMappings: Record<string, string> = {
      "Account Name": accountName,
      Birthdate: birthDate,
      "Gender Identity": genderIdentity,
      "Preferred Language": preferredLanguage,
      "Household Size": "",
      "Annual Household Income": "",
    };
    await this.verifyAccountFields(fieldMappings);
    await this.verifyAccountRecordType("Patient");
    await this.verifyCheckboxField("Do Not Contact Patient", doNotContactPatient);
  }
  /**
   * Removes non-numeric characters from a phone number.
   *
   * @param phoneNumber Phone number to normalize.
   * @returns Digits-only phone number.
   * @author Pavan Kumar
   */
  public normalizePhoneNumber(phoneNumber: string): string {
    return phoneNumber.replace(/\D/g, "");
  }

  /**
   * Scrolls the page until the specified related list is visible.
   *
   * @param relatedListName Name of the related list to locate.
   * @param maxScrolls Maximum number of scroll attempts.
   * @returns Promise that resolves when the related list is found.
   * @throws Error if the related list is not found after all scroll attempts.
   * @author Pavan Kumar
   */
  public async scrollUntilRelatedListVisible(relatedListName: string, maxScrolls: number = 15): Promise<void> {
    const locator = relatedListTitleDynXpath.replace("%s", relatedListName);
    for (let i = 0; i < maxScrolls; i++) {
      if (await this.actionEngine.isElementPresentDOM(locator)) {
        return;
      }
      await this.page.mouse.wheel(0, 1500);
      await this.page.waitForTimeout(1000);
    }
    throw new Error(`${relatedListName} related list not found after scrolling`);
  }

  /**
   * Opens the specified related list by scrolling to it and clicking the View All link.
   *
   * @param relatedListName Name of the related list to open.
   * @returns Promise that resolves when the related list is opened.
   * @author Pavan Kumar
   */
  public async openRelatedList(relatedListName: string): Promise<void> {
    await this.scrollUntilRelatedListVisible(relatedListName);
    const locator = relatedListViewAllDynXpath.replace("%s", relatedListName);
    await this.actionEngine.clickElement(locator, `View All ${relatedListName}`);
  }

  /**
   * Retrieves all row and cell data from the specified related list table.
   *
   * @param tableName Name of the related list table.
   * @returns Two-dimensional array containing table row data.
   * @author Pavan Kumar
   */
  public async getTableData(tableName: string): Promise<string[][]> {
    const rows = this.page.locator(tableRowsDynXpath.replace("%s", tableName));
    const rowCount = await rows.count();
    const tableData: string[][] = [];
    for (let i = 0; i < rowCount; i++) {
      const row = rows.nth(i);
      const rowData: string[] = [];
      const headerText = (await row.locator(tableHeaderCellXpath).textContent())?.trim() ?? "";
      rowData.push(headerText);
      const cells = row.locator(tableCellsXpath);
      const cellCount = await cells.count();
      for (let j = 0; j < cellCount; j++) {
        rowData.push((await cells.nth(j).textContent())?.trim() ?? "");
      }
      tableData.push(rowData);
    }
    return tableData;
  }

  /**
   * Verifies that a phone record exists in the Phones related list
   * with the expected phone number and phone type.
   *
   * @param expectedPhoneNumber Expected phone number.
   * @param expectedPhoneType Expected phone type.
   * @author Pavan Kumar
   */
  public async verifyPhoneRecord(expectedPhoneNumber: string, expectedPhoneType: string): Promise<void> {
    const tableData = await this.getTableData("Phones");
    const recordFound = tableData.some((row) => row[0] === expectedPhoneNumber && row[1] === expectedPhoneType);
    expect(
      recordFound,
      `Phone record not found. Expected Phone: ${expectedPhoneNumber}, Type: ${expectedPhoneType}`
    ).toBeTruthy();
  }

  /**
   * Verifies that an email record exists in the Emails related list.
   *
   * @param expectedEmail Expected email address.
   * @author Pavan Kumar
   */
  public async verifyEmailRecord(expectedEmail: string): Promise<void> {
    const tableData = await this.getTableData("Emails");
    const recordFound = tableData.some((row) => row.some((cell) => cell.toLowerCase() === expectedEmail.toLowerCase()));
    expect(recordFound, `Email record not found: ${expectedEmail}`).toBeTruthy();
  }

  /**
   * Verifies that Home and Mobile phone records are created and
   * displayed in the Phones related list with the expected headers.
   * @author Pavan Kumar
   */
  public async verifyPhoneRecords(): Promise<void> {
    const phoneRecords = [
      {
        number: this.normalizePhoneNumber(fileConfigUtil.getData("HomePhone") ?? ""),
        type: "Home",
      },
      {
        number: this.normalizePhoneNumber(fileConfigUtil.getData("CellPhone") ?? ""),
        type: "Mobile",
      },
    ];
    await this.openRelatedList("Phones");
    for (const phone of phoneRecords) {
      await this.verifyPhoneRecord(phone.number, phone.type);
    }
    await this.verifyTableHeaders("Phones", ["Telephone number", "Phone Type", "Is Primary", "Is SMS capable"]);
    await captureEvidenceScreenshot(this.page, this.testInfo, "Contact Point Phone Records Verification");
    await this.page.goBack();
  }
  /**
   * Verifies that the expected email record is created and displayed
   * in the Emails related list along with the required table headers.
   * @author Pavan Kumar
   */
  public async verifyEmailRecords(): Promise<void> {
    const email = fileConfigUtil.getData("Email") ?? "";
    await this.openRelatedList("Emails");
    await this.verifyEmailRecord(email);
    await this.verifyTableHeaders("Emails", [
      "Email address",
      "Usage Type",
      "Is Primary",
      "Email latest bounce date time",
    ]);
    await captureEvidenceScreenshot(this.page, this.testInfo, "Contact Point Email Records Verification");
    await this.page.goBack();
  }

  /**
   * Verifies expected headers in a related list table.
   *
   * @param tableName Related list name.
   * @param expectedHeaders Expected column headers.
   * @author Pavan Kumar
   */
  public async verifyTableHeaders(tableName: string, expectedHeaders: string[]): Promise<void> {
    const headers = this.page.locator(relatedListTableHeaderDynXpath.replace("%s", tableName));
    const actualHeaders = (await headers.allTextContents()).map((header) => header.trim());
    for (const expectedHeader of expectedHeaders) {
      expect(actualHeaders, `${expectedHeader} column is not displayed in ${tableName} table`).toContain(
        expectedHeader
      );
    }
  }

  /**
   * Verifies that the expected Contact Point Address record exists in the
   * Contact Point Addresses related list.
   *
   * @author Pavan Kumar
   */
  public async verifyContactPointAddressRecord(): Promise<void> {
    const patientInfo = testData.PATIENTINFORMATIONDATA as unknown as Record<string, string>;
    const expectedAddress = [
      patientInfo["Patient Street"] ?? "",
      patientInfo["Patient City"] ?? "",
      patientInfo["Patient State"] ?? "",
      patientInfo["Patient ZIP"] ?? "",
    ];
    const tableData = await this.getTableData("Contact Point Addresses");
    const recordFound = tableData.some((row) =>
      expectedAddress.every((value) => row.some((cell) => cell.includes(value)))
    );
    expect(recordFound, `Address record not found. Expected address: ${expectedAddress.join(", ")}`).toBeTruthy();
  }

  /**
   * Verifies that the Contact Point Address record is displayed
   * in the Contact Point Addresses related list.
   *
   * @author Pavan Kumar
   */
  public async verifyContactPointAddressRecords(): Promise<void> {
    await this.openRelatedList("Contact Point Addresses");
    await this.verifyContactPointAddressRecord();
    await captureEvidenceScreenshot(this.page, this.testInfo, "Contact Point Address Records Verification");
    await this.page.goBack();
  }

  /**
   * Verifies that the GPF phone record is displayed in the Phones related list
   * with the expected phone type and required table headers.
   *
   * @author Pavan Kumar
   */
  public async verifyGPFPhoneRecords(): Promise<void> {
    const patientInfo = testData.PATIENTINFORMATIONDATA as unknown as Record<string, string>;
    const phoneNumber = this.normalizePhoneNumber(fileConfigUtil.getData("Phone") ?? "");
    let phoneType = patientInfo["Phone Type"]?.trim() ?? "";
    switch (phoneType.toLowerCase()) {
      case "cell":
        phoneType = "Mobile";
        break;
      case "home":
        phoneType = "Home";
        break;
    }
    await this.openRelatedList("Phones");
    await this.verifyPhoneRecord(phoneNumber, phoneType);
    await this.verifyTableHeaders("Phones", ["Telephone number", "Phone Type", "Is Primary", "Is SMS capable"]);
    await this.page.goBack();
  }
  /**
   * Verifies that no phone records are created in the Phones related list.
   *
   * @author Pavan Kumar
   */
  public async verifyPhoneRecordsNotCreated(): Promise<void> {
    await this.verifyNoRecordsCreated("Phones");
  }

  /**
   * Verifies that no email records are created in the Emails related list.
   *
   * @author Pavan Kumar
   */
  public async verifyEmailRecordsNotCreated(): Promise<void> {
    await this.verifyNoRecordsCreated("Emails");
  }

  /**
   * Verifies that no Contact Point Address records are created
   * in the Contact Point Addresses related list.
   *
   * @author Pavan Kumar
   */
  public async verifyContactPointAddressRecordsNotCreated(): Promise<void> {
    await this.verifyNoRecordsCreated("Contact Point Addresses");
  }
  /**
   * Verifies that no records are created in the specified related list.
   *
   * @param tableName Related list name.
   * @author Pavan Kumar
   */
  public async verifyNoRecordsCreated(tableName: string): Promise<void> {
    await this.scrollUntilRelatedListVisible(tableName);
    const tableData = await this.getTableData(tableName);
    expect(tableData.length, `${tableName} records should not be created`).toBe(0);
    await captureEvidenceScreenshot(this.page, this.testInfo, `${tableName} No Records Verification`);
  }
}
