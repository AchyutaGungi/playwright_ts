import { testData } from "../utils/common/TestDataUtil.js";
import { Page, expect, TestInfo } from "@playwright/test";
import { fileConfigUtil } from "../utils/common/FileConfigUtil.js";
import { faker } from "@faker-js/faker";
import path from "path";
import { ActionEngineUtil } from "../utils/ui/ActionEngineUtil.js";
import { CommonPage } from "../pages/CommonPage.js";

const tabNameDynXpath: string = "//li/a[@data-label='%s']";
const dropdownOptionDynXpath: string = "//lightning-base-combobox-item[@data-value='%s']";
const pageNameDynXpath: string = "//div[text()='%s' and @role='heading']";
const requiredErrorMsgDynXpath: string = "//*[text()='Error: %s is required.']";
const sectionHeaderDynXpath: string = "//h3[text()='%s']";
const inputFieldDynXpath: string = "//*[self::label or self::legend][.//*[normalize-space()='%s']]/following::input[1]";
const radioButtonDynXpath = '//span[normalize-space()="%s"]/ancestor::fieldset//label';
const radioButtonInputDynXpath = '//span[normalize-space()="%s"]/ancestor::fieldset//input[@type="radio"]';
const checkboxDynXpath: string = "//input[@value='%s']/following-sibling::label";
const inputDateFieldDynXpath: string = "input[aria-label='%s']";
const inputTextFieldDynXpath: string = "//label[.//span[normalize-space()='%s']]/../following-sibling::div//input";
const radioFieldDynXpath: string = '//legend[.//span[normalize-space()="%s"]]/following-sibling::div//input';
const pickListFieldDynXpath: string =
  "//label[.//span[normalize-space()='%s']]/../following-sibling::div//*[@role='combobox']";
const payerSearchResultDynXpath: string = "//*[contains(text(),'%s')]";
const pickListOptionDynXpath: string = "//span[@title='%s']";

const primaryInsuranceSearchInput =
  "//*[@data-omni-key='PrimaryInsuranceSearch']//input[@placeholder='Search Payers...']";
const secondaryInsuranceSearchInput = "//*[@data-omni-key='Secondarypayer']//input[@placeholder='Search Payers...']";
const pharmacyBenefitSearchInput = "//*[@data-omni-key='PharmacyBenefit']//input[@placeholder='Search Payers...']";
const prescriberSearchInput = "//*[@data-omni-key='PrescriberInfo' or @data-omni-key='PrescriberInfoSearch']//input";
const treatmentSiteLocSearchInput = "//*[@data-omni-key='TreatmentSiteLoc']//input";
const nameInputTextbox = "input[name='Name']";
const saveBtn = "button[name='SaveEdit']";
const statusBtn = "button[aria-label='Status']";
const classificationBtn = "//button[@aria-label='Document Type']";
const doneBtn = "//button/span[text()='Done']";
const inputFile = "input[type='file']";
const documentSubTypeBtn = "//button[@aria-label='Document Sub-Type']";
const patientSearchComponent = "//div[text()='Patient Search' or text()='PATIENT SEARCH']";
const siteOfTreatmentSearchComponent = "//div[text()='Site Of Treatment Search']";
const nextBtn = "//button[normalize-space()='Next']";
const submitBtn = "//button[normalize-space()='Submit']";
const enrollmentSubmittedMessage = "//h2[text()='Enrollment Submitted']";
const enrollmentSuccessMessage = "//sub[text()='OCREVUS Start Form has been recorded successfully.']";
const sourceInputTextbox = "input[name='Source']";
const enrollmentGPFSubmittedMessage = "//h2[text()='GPF Enrollment Submitted']";
const enrollmentGPFSuccessMessage =
  "//sub[contains(text(),'Genentech Patient Foundation Form has been recorded successfully. SUCESS')]";
const consentFormSubmittedMessage = "//h2[text()='Form Submitted']";
const consentFormSuccessMessage = "//sub[text()='Consent Form has been recorded successfully.']";

export class ReceivedDocumentPage {
  private page: Page;
  private actionEngine: ActionEngineUtil;
  private testInfo: TestInfo;
  private commonPage: CommonPage;
  /**
   * This constructor is used to initialize the ReceivedDocumentPage with page
   * @param page
   * @author SurendraKumarVetcha
   */
  constructor(page: Page, testInfo: TestInfo) {
    this.page = page;
    this.actionEngine = new ActionEngineUtil(this.page);
    this.testInfo = testInfo;
    this.commonPage = new CommonPage(this.page, testInfo);
  }

  /**
   * Sets the Status field in the Received Document Details section.
   * @param status
   * @author PavanKumar
   */
  async selectStatus(status: string) {
    await this.page.locator(statusBtn).click();
    const formattedStatus = status.trim().replace(/\s+/g, "_").toUpperCase();
    const dynxpath = dropdownOptionDynXpath.replace("%s", formattedStatus);
    const statusOption = this.page.locator(dynxpath);
    await this.actionEngine.waitForElementVisible(dynxpath);
    await statusOption.scrollIntoViewIfNeeded();
    await this.actionEngine.clickElement(dynxpath, `${status} Status`);
  }

  /**
   * This method is used to fill Received Document Details
   * @author PavanKumar
   */
  async fillReceivedDocumentDetails() {
    const receivedDocumentName = testData.FIRSTNAME || faker.person.firstName();
    fileConfigUtil.insertData("ReceivedDocumentName", receivedDocumentName);
    await this.page.locator(nameInputTextbox).fill(receivedDocumentName);
    await this.selectStatus("Draft");
    await this.actionEngine.enterText(sourceInputTextbox, "Fax", "Source");
    await this.actionEngine.clickElement(saveBtn, "Save Button");
    await this.page.waitForTimeout(6000);
  }

  /**
   * This method is used to upload a document from the project folder
   * to the Received Document record.
   * @param fileName
   * @author Pavan Kumar
   */
  async uploadDocument(fileName: string): Promise<void> {
    const filePath = path.resolve(process.cwd(), "testdata", "documents", fileName);
    await this.page.locator(inputFile).filter({ visible: true }).setInputFiles(filePath);
    await this.page.waitForTimeout(10000);
    await this.actionEngine.verifyElementVisible(doneBtn, "Done Button");
    await expect(this.page.locator(doneBtn)).toBeEnabled();
    await this.actionEngine.clickElement(doneBtn, "Done Button");
    await this.page.waitForTimeout(5000);
    await this.page.reload();
    await this.page.waitForTimeout(5000);
  }

  /**
   * This method clicks on the specified tab.
   * @param tabName Name of the tab to click.
   * @author PavanKumar
   */
  public async clickTab(tabName: string): Promise<void> {
    const tab = this.page.locator(tabNameDynXpath.replace("%s", tabName)).filter({ visible: true });
    await this.actionEngine.clickFilteredLocator(tab, `${tabName} Tab`);
  }

  /**
   * Sets the Classifications field in the Received Document Viewer section.
   * @param classification
   * @author PavanKumar
   */
  async selectClassifications(classification: string) {
    await this.actionEngine.clickElement(classificationBtn, "Classification");
    const dynxpath = dropdownOptionDynXpath.replace("%s", classification);
    await this.actionEngine.waitForElementVisible(dynxpath);
    await this.actionEngine.clickElement(dynxpath, classification);
  }

  /**
   * Sets the Document Sub-Type field in the Received Document Viewer section.
   * @param documentSubType
   * @author PavanKumar
   */
  async selectDocumentSubType(documentSubType: string) {
    await this.actionEngine.clickElement(documentSubTypeBtn, "Document Sub Type");
    const dynxpath = dropdownOptionDynXpath.replace("%s", documentSubType);
    await this.actionEngine.waitForElementVisible(dynxpath);
    await this.actionEngine.clickElement(dynxpath, documentSubType);
  }

  /**
   * Verify Patient Information page is displayed.
   * @param page
   * @author Pavan Kumar
   */
  async verifyPatientInformationPageDisplayed(page: string) {
    await this.actionEngine.verifyElementVisible(pageNameDynXpath.replace("%s", page), `${page} Page`);
  }

  /**
   * Verify Patient Search component is displayed.
   * @author PavanKumar
   */
  async verifyPatientSearchComponentDisplayed() {
    await this.actionEngine.verifyElementVisible(patientSearchComponent, "Patient Search Component");
  }

  /**
   * Retrieves field configuration for the specified page from test data.
   *
   * @param page Page name.
   * @returns Page field configuration.
   * @author Pavan Kumar
   */
  private getPageFields(page: string) {
    const pageFieldKey = `${page.replace(/[^a-zA-Z0-9]/g, "").toUpperCase()}FIELDS`;
    const fields = testData[pageFieldKey] as unknown as Record<
      string,
      | string
      | {
          type: string;
          count?: number;
          readonly?: boolean;
        }
    >;
    if (!fields) {
      throw new Error(`No field configuration found for '${page}'`);
    }
    return fields;
  }

  /**
   * Verifies that the specified radio button field is displayed
   * with the expected radio button options.
   *
   * @param fieldName Radio button field label.
   * @author Pavan Kumar
   */
  private async verifyRadioField(fieldName: string): Promise<void> {
    const radioButtons = this.page.locator(radioButtonInputDynXpath.replace("%s", fieldName));
    await expect(radioButtons.first()).toBeVisible();
    await expect(radioButtons).toHaveCount(2);
    await expect(radioButtons.first()).toHaveAttribute("type", "radio");
  }
  /**
   * Returns locator mappings for supported field types.
   *
   * @returns Field type and locator mapping.
   * @author Pavan Kumar
   */
  private getFieldTypeLocators(): Record<string, string> {
    return {
      text: inputTextFieldDynXpath,
      phone: inputTextFieldDynXpath,
      email: inputTextFieldDynXpath,
      date: inputDateFieldDynXpath,
      checkbox: checkboxDynXpath,
      picklist: pickListFieldDynXpath,
    };
  }

  /**
   * Returns expected attributes for supported field types.
   *
   * @returns Field type attribute mappings.
   * @author Pavan Kumar
   */
  private getFieldTypeAttributes(): Record<string, [string, string | RegExp]> {
    return {
      text: ["type", "text"],
      phone: ["type", "tel"],
      email: ["type", "email"],
      date: ["placeholder", /^(MM\/DD\/YYYY|mm\/dd\/yyyy)$/],
      checkbox: ["type", "checkbox"],
      picklist: ["role", "combobox"],
    };
  }

  /**
   * Verifies the specified field is displayed with the expected type,
   * count, and read-only state.
   *
   * @param fieldName Field label.
   * @param fieldType Field type.
   * @param count Expected number of fields.
   * @param readonly Indicates whether the field is read-only.
   * @author Pavan Kumar
   */
  private async verifyField(fieldName: string, fieldType: string, count: number, readonly: boolean): Promise<void> {
    const locatorXpath = this.getFieldTypeLocators()[fieldType];
    if (!locatorXpath) {
      throw new Error(`Unsupported field type '${fieldType}' for field '${fieldName}'`);
    }
    const elements = this.page.locator(locatorXpath.replace("%s", fieldName));
    if (count > 1) {
      await expect(elements).toHaveCount(count);
    }
    const attributeConfig = this.getFieldTypeAttributes()[fieldType];
    if (!attributeConfig) {
      throw new Error(`No attribute mapping found for field type '${fieldType}'`);
    }
    const [attribute, expectedValue] = attributeConfig;
    for (let index = 0; index < count; index++) {
      const element = count > 1 ? elements.nth(index) : elements.first();
      await expect(element).toBeVisible();
      if (readonly) {
        await expect(element).toHaveAttribute("readonly", "");
      }
      await expect(element).toHaveAttribute(attribute, expectedValue);
    }
  }
  /**
   * Verifies all configured fields are displayed on the specified page.
   *
   * @param page Page name.
   * @author Pavan Kumar
   */
  public async verifyFieldsDisplayed(page: string): Promise<void> {
    try {
      const fields = this.getPageFields(page);
      for (const [fieldName, fieldConfig] of Object.entries(fields)) {
        const {
          type,
          count = 1,
          readonly = false,
        } = typeof fieldConfig === "string" ? { type: fieldConfig } : fieldConfig;
        if (type === "multicheckbox") {
          continue;
        }
        if (type === "radio") {
          await this.verifyRadioField(fieldName);
          continue;
        }
        await this.verifyField(fieldName, type, count, readonly);
      }
    } catch (error) {
      throw new Error(`Failed to verify fields for '${page}'. Error: ${error}`);
    }
  }

  /**
   * Verify all configured values are displayed in the specified picklist.
   * @param picklist Picklist label.
   * @author Pavan Kumar
   */
  public async verifyPickListValuesDisplayed(picklist: string): Promise<void> {
    try {
      const picklistXpath = pickListFieldDynXpath.replace("%s", picklist);
      await this.actionEngine.clickElement(picklistXpath, `${picklist} Picklist`);
      const picklistKey = picklist.replace(/\s+/g, "").toUpperCase();
      const expectedValues = testData[picklistKey];
      if (!expectedValues?.length) {
        throw new Error(`No test data found for picklist '${picklist}'`);
      }
      for (const value of expectedValues) {
        const option = this.page.locator(pickListOptionDynXpath.replace("%s", value)).filter({ visible: true }).first();
        await expect(option, `Picklist value '${value}' is not displayed`).toBeVisible();
      }
      await this.actionEngine.pressKey("Escape");
    } catch (error) {
      throw new Error(`Failed to verify values for picklist '${picklist}'. Error: ${error}`);
    }
  }

  /**
   * Click Next button.
   * @author PavanKumar
   */
  async clickNextButton() {
    const nextButton = this.page.locator(nextBtn).first();
    await this.actionEngine.clickFilteredLocator(nextButton, "Next Button");
  }

  /**
   * Click Submit button.
   * @author PavanKumar
   */
  async clickSubmitButton() {
    const submitButton = this.page.locator(submitBtn).first();
    await this.actionEngine.clickFilteredLocator(submitButton, "Submit Button");
    await this.page.waitForTimeout(5000);
  }

  /**
   * Verifies that all required field error messages are displayed.
   *
   * @param page - Page name for which validation is performed.
   * @author Pavan Kumar
   */
  async verifyRequiredFieldErrorMessagesDisplayed(page: string): Promise<void> {
    const requiredFields = testData[page.replace(/\s+/g, "").toUpperCase()]!;
    for (const field of requiredFields) {
      const errorMessage = this.page.locator(requiredErrorMsgDynXpath.replace("%s", field));
      await this.actionEngine.verifyLocatorVisible(errorMessage, `Required error message for ${field}`);
    }
  }

  /**
   * Selects a radio button option.
   *
   * @param field - Field name.
   * @param option - Option to select.
   * @author Pavan Kumar
   */
  public async selectRadioButton(fieldName: string, value: string): Promise<void> {
    const radioButtons = this.page.locator(radioButtonDynXpath.replace("%s", fieldName));
    if (value.toLowerCase() === "yes") {
      await radioButtons.nth(0).check();
    } else {
      await radioButtons.nth(1).check();
    }
  }

  /**
   * Verifies that all Insurance Information fields are displayed and
   * readonly where applicable.
   * @author Pavan Kumar
   */
  public async verifyInsuranceInformationFieldsDisplayed(): Promise<void> {
    const readOnlyFields = testData.INSURANCEFIELDSREADONLY!;
    for (const field of readOnlyFields) {
      const fieldElements = this.page.locator(inputFieldDynXpath.replace("%s", field));
      await expect(fieldElements, `${field} should have 3 instances`).toHaveCount(3);
      const count = await fieldElements.count();
      for (let index = 0; index < count; index++) {
        const fieldElement = fieldElements.nth(index);
        await expect(fieldElement, `${field} should be visible`).toBeVisible();
        await expect(fieldElement, `${field} should be readonly`).toHaveAttribute("readonly", "");
      }
    }
    for (const field of testData.INSURANCEFIELDS!) {
      await this.actionEngine.verifyElementVisible(inputFieldDynXpath.replace("%s", field), field);
    }
  }

  /**
   * Verifies that all Insurance Information section headers are displayed.
   *
   * @author Pavan Kumar
   */
  async verifySectionHeadersDisplayed(): Promise<void> {
    const sections = testData.INSURANCESECTIONS!;
    for (const section of sections) {
      const sectionHeader = this.page.locator(sectionHeaderDynXpath.replace("%s", section));
      await this.actionEngine.verifyLocatorVisible(sectionHeader, `${section} Section Header`);
    }
  }

  /**
   * Verify checkbox is displayed.
   * @param checkboxValue
   * @author Pavan Kumar
   */
  async verifyCheckboxDisplayed(checkboxValue: string) {
    await this.actionEngine.verifyElementVisible(
      checkboxDynXpath.replace("%s", checkboxValue),
      `${checkboxValue} Checkbox`
    );
  }

  /**
   * Select checkbox value.
   * @param checkboxValue
   * @author Pavan Kumar
   */
  async selectCheckbox(checkboxValue: string) {
    const checkbox = this.page.locator(checkboxDynXpath.replace("%s", checkboxValue));
    await checkbox.check();
  }

  /**
   * Verifies that the Site of Treatment Search component is displayed.
   *
   * @author Pavan Kumar
   */
  async verifySiteOfTreatmentSearchComponentDisplayed() {
    await this.actionEngine.verifyElementVisible(siteOfTreatmentSearchComponent, "Site Of Treatment Search Component");
  }

  /**
   * Verifies fields are read-only.
   * @author Pavan Kumar
   */
  async verifyFieldsAreReadOnly(page: string) {
    const pageFieldKey = `${page.replace(/[^a-zA-Z0-9]/g, "").toUpperCase()}FIELDSREADONLY`;
    const fields = testData[pageFieldKey]!;
    for (const field of fields) {
      const fieldElement = this.page.locator(inputFieldDynXpath.replace("%s", field));
      await expect(fieldElement).toHaveAttribute("readonly", "");
      // Additional validations only for Starter Rx page
      if (page.toUpperCase() === "STARTERRX") {
        switch (field) {
          case "OCREVUS ZUNOVO (920 mg/23 mL)":
            await expect(fieldElement).toHaveValue("OCREVUS ZUNOVO (920 mg/23 mL)");
            break;
          case "Quantity":
            await expect(fieldElement).toHaveValue("1");
            break;
          case "Refills":
            await expect(fieldElement).toHaveValue("0");
            break;
        }
      }
    }
  }

  /**
   * Verifies that the Enrollment Submitted success message is displayed.
   * @author Pavan Kumar
   */
  async verifyEnrollmentSubmittedMessageDisplayed() {
    await this.actionEngine.waitForElementVisible(enrollmentSubmittedMessage, 60000);
    await this.actionEngine.verifyElementVisible(enrollmentSubmittedMessage, "Enrollment Submitted Message");
    await this.actionEngine.verifyElementVisible(enrollmentSuccessMessage, "Enrollment Success Message");
  }

  /**
   * Select a value from the specified picklist field.
   * @param fieldName - Picklist field label.
   * @param value - Value to be selected from the picklist.
   * @author Pavan Kumar
   */
  public async selectPicklistValue(fieldName: string, value: string): Promise<void> {
    await this.page.locator(pickListFieldDynXpath.replace("%s", fieldName)).click();
    await this.page.locator(pickListOptionDynXpath.replace("%s", value)).filter({ visible: true }).click();
  }

  /**
   * Enter a value into the specified field based on its control type.
   * Supports radio buttons, picklists, date fields, and text fields.
   * @param fieldName - Field label displayed on the page.
   * @param value - Value to be entered or selected.
   * @author Pavan Kumar
   */
  public async enterField(fieldName: string, value: string): Promise<void> {
    try {
      const radioField = radioFieldDynXpath.replace("%s", fieldName);
      const picklistField = pickListFieldDynXpath.replace("%s", fieldName);
      const dateField = inputDateFieldDynXpath.replace("%s", fieldName);

      if ((await this.page.locator(radioField).count()) > 0) {
        return await this.selectRadioButton(fieldName, value);
      }
      if ((await this.page.locator(picklistField).count()) > 0) {
        return await this.selectPicklistValue(fieldName, value);
      }
      if ((await this.page.locator(dateField).count()) > 0) {
        await this.page.locator(dateField).pressSequentially(value, { delay: 100 });
        return;
      }
      await this.page.locator(inputTextFieldDynXpath.replace("%s", fieldName)).filter({ visible: true }).fill(value);
    } catch (error) {
      throw new Error(`Failed to enter value '${value}' for field '${fieldName}'. Error: ${error}`);
    }
  }

  /**
   * Fill all fields in the specified form section using test data.
   * Generates dynamic values when test data is blank and enters
   * values into the corresponding field types.
   * @param sectionName - Section name used to derive the test data key.
   * @author Pavan Kumar
   */
  public async fillFormSection(sectionName: string): Promise<void> {
    try {
      const jsonKey = sectionName.replace(/\s+/g, "").toUpperCase() + "DATA";
      const sectionData = (testData[jsonKey] as unknown as Record<string, string>) ?? {};
      for (const [fieldName, fieldValue] of Object.entries(sectionData)) {
        const value = this.getFieldValue(fieldName, fieldValue);
        if (fieldName in this.searchFields) {
          await this.searchAndSelect(fieldName, value);
        } else {
          await this.enterField(fieldName, value);
        }
      }
    } catch (error) {
      throw new Error(`Failed to fill ${sectionName}. Error: ${error}`);
    }
  }

  /**
   * Generates the current date in MM/DD/YYYY format.
   * @returns Current date formatted for form entry.
   * @author Pavan Kumar
   */
  public readonly currentDate = () =>
    new Date().toLocaleDateString("en-US", {
      month: "2-digit",
      day: "2-digit",
      year: "numeric",
    });

  /**
   * Generates a random date of birth for an adult between 18 and 65 years old
   * in MM/DD/YYYY format.
   * @returns Generated date of birth.
   * @author Pavan Kumar
   */
  public readonly dob = () =>
    faker.date.birthdate({ min: 18, max: 65, mode: "age" }).toLocaleDateString("en-US", {
      month: "2-digit",
      day: "2-digit",
      year: "numeric",
    });

  /**
   * Generates dynamic values for supported fields and stores them
   * for subsequent test validations.
   * @author Pavan Kumar
   */
  public readonly fieldGenerators: Record<string, () => string> = {
    "First Name": () => this.store("FirstName", faker.person.firstName()),
    "Last Name": () => this.store("LastName", faker.person.lastName()),
    Email: () => this.store("Email", faker.internet.email()),
    "Home Phone": () => this.store("HomePhone", this.generatePhoneNumber()),
    "Cell Phone": () => this.store("CellPhone", this.generatePhoneNumber()),
    Phone: () => this.store("Phone", this.generatePhoneNumber()),
    "Alternate Contact Name": () => this.store("AlternateContactFullName", faker.person.fullName()),
    "Alternate Contact Phone": () => this.store("AlternateContactPhone", this.generatePhoneNumber()),
    "Person Signing First Name": () => this.store("PersonSigningFirstName", faker.person.firstName()),
    "Person Signing Last Name": () => this.store("PersonSigningLastName", faker.person.lastName()),
    "Household Size": () => this.store("HouseholdSize", faker.number.int({ min: 1, max: 8 }).toString()),
    "Annual Household Income": () =>
      this.store("AnnualHouseholdIncome", faker.number.int({ min: 20000, max: 200000 }).toString()),
    "Date of Birth": () => this.store("DOB", this.dob()),
    "Date Signed": () => this.store("DateSigned", this.currentDate()),
    "Provider Signature Date": () => this.store("ProviderSignatureDate", this.currentDate()),
  };

  /**
   * Stores generated test data for later validation and returns the value.
   * @param key - Test data key.
   * @param value - Generated or provided value.
   * @returns Stored value.
   * @author Pavan Kumar
   */
  public store(key: string, value: string): string {
    fileConfigUtil.insertData(key, value);
    return value;
  }

  /**
   * Maps equivalent field labels used across different forms.
   * Used to handle variations in field names while maintaining
   * consistent data generation and validation.
   * @author Pavan Kumar
   */
  public readonly aliases: Record<string, string[]> = {
    "Date of Birth": ["Date of Birth", "Date of Birth (DOB)"],
    "Alternate Contact Name": ["Alternate Contact Name", "Alternate Contact Full Name"],
    "Annual Household Income": ["Annual Household Income", "Annual Household Income(Enter dollar amount (e.g. 45000))"],
  };

  /**
   * Retrieves a field value from test data or generates one dynamically
   * when the test data value is empty. Field aliases are resolved to
   * ensure consistent data generation across forms.
   * @param fieldName - Field name.
   * @param fieldValue - Test data value.
   * @returns Field value to be used during form entry.
   * @author Pavan Kumar
   */
  public getFieldValue(fieldName: string, fieldValue: string): string {
    if (fieldValue) {
      return fieldValue;
    }
    const normalizedFieldName =
      Object.entries(this.aliases).find(([, aliases]) => aliases.includes(fieldName))?.[0] ?? fieldName;
    return this.fieldGenerators[normalizedFieldName]?.() ?? "";
  }

  /**
   * Generates a valid test phone number for use in form submissions
   * Format: (XXX) XXX-XXXX
   * @returns Generated phone number.
   * @author Pavan Kumar
   */
  public generatePhoneNumber(): string {
    return `(${faker.string.numeric(3)}) ${faker.string.numeric(3)}-${faker.string.numeric(4)}`;
  }

  /**
   * Mapping of searchable fields to their corresponding search input locators.
   * Used to identify fields that require search-and-select functionality
   * instead of standard data entry during form completion.
   * @author Pavan Kumar
   */
  public readonly searchFields: Record<string, string> = {
    "Primary Insurance": primaryInsuranceSearchInput,
    "Secondary Insurance": secondaryInsuranceSearchInput,
    "Pharmacy Benefit": pharmacyBenefitSearchInput,
    Prescriber: prescriberSearchInput,
    "Treatment Site Location": treatmentSiteLocSearchInput,
  };

  /**
   * Searches for and selects a value from the specified lookup field.
   * @param fieldName - Lookup field name.
   * @param value - Value to search and select.
   * @author Pavan Kumar
   */
  public async searchAndSelect(fieldName: string, value: string): Promise<void> {
    try {
      const searchLocator = this.searchFields[fieldName.trim()];
      if (!searchLocator) {
        throw new Error(`No search locator configured for '${fieldName}'`);
      }
      const searchValue = value.trim();
      await this.actionEngine.enterText(searchLocator, searchValue, fieldName);
      await this.actionEngine.clickFilteredLocator(
        this.page.locator(payerSearchResultDynXpath.replace("%s", searchValue)).first(),
        `${fieldName} Search Result`
      );
    } catch (error) {
      throw new Error(`Failed to select '${value}' from '${fieldName}'. Error: ${error}`);
    }
  }

  /**
   * Verify that all fields configured for the specified page are not displayed.
   * @param page - Page name used to retrieve field data from the test data file.
   * @author Pavan Kumar
   */
  public async verifyFieldsNotDisplayed(page: string): Promise<void> {
    try {
      const fields = this.getPageFields(page);
      for (const [fieldName, fieldConfig] of Object.entries(fields)) {
        const { type } = typeof fieldConfig === "string" ? { type: fieldConfig } : fieldConfig;
        if (type === "multicheckbox") {
          continue;
        }
        const locatorXpath = this.getFieldTypeLocators()[type];
        if (!locatorXpath) {
          throw new Error(`Unsupported field type '${type}' for field '${fieldName}'`);
        }
        const element = this.page.locator(locatorXpath.replace("%s", fieldName));
        await expect(element.first(), `${fieldName} should not be displayed`).not.toBeVisible();
      }
    } catch (error) {
      throw new Error(`Failed to verify hidden fields for page '${page}'. Error: ${error}`);
    }
  }

  /**
   * Verify Treatment Site fields are displayed or hidden
   * based on the selected Shipment To value.
   * @author Pavan Kumar
   */
  public async verifyConditionalTreatmentSiteDisplay(): Promise<void> {
    // Shipment To = Prescriber/Practice
    await this.selectPicklistValue("Shipment To", "Prescriber/Practice");
    await this.verifyFieldsDisplayed("Shipment Information");
    // Shipment To = Patient
    await this.selectPicklistValue("Shipment To", "Patient");
    await this.verifyFieldsNotDisplayed("Shipment Information");
  }

  /**
   * Verifies that the Enrollment GPF Submitted success message is displayed.
   * @author Pavan Kumar
   */
  async verifyEnrollmentGPFSubmittedMessageDisplayed() {
    await this.actionEngine.waitForElementVisible(enrollmentGPFSubmittedMessage, 60000);
    await this.actionEngine.verifyElementVisible(enrollmentGPFSubmittedMessage, "GPF Submitted Message");
    await this.actionEngine.verifyElementVisible(enrollmentGPFSuccessMessage, "GPF Success Message");
  }

  /**
   * Verifies that the Enrollment GPF Submitted success message is displayed.
   * @author Pavan Kumar
   */
  async verifyConsentFormSubmittedMessageDisplayed() {
    await this.actionEngine.waitForElementVisible(consentFormSubmittedMessage, 60000);
    await this.actionEngine.verifyElementVisible(consentFormSubmittedMessage, "Consent Submitted Message");
    await this.actionEngine.verifyElementVisible(consentFormSuccessMessage, "Consent Success Message");
  }

  /**
   * Verifies the available checkbox options for a multi-checkbox field.
   *
   * @param fieldName Multi-checkbox field label.
   * @param expectedValues Expected checkbox values.
   * @author Pavan Kumar
   */
  public async verifyMultiCheckboxOptions(fieldName: string, expectedValues: string[]): Promise<void> {
    const checkboxes = this.page.locator(radioFieldDynXpath.replace("%s", fieldName));
    await expect(checkboxes, `${fieldName} should have ${expectedValues.length} options`).toHaveCount(
      expectedValues.length
    );
    for (let index = 0; index < expectedValues.length; index++) {
      const checkbox = checkboxes.nth(index);
      const expectedValue = expectedValues[index];
      if (!expectedValue) {
        throw new Error(`Missing expected value for '${fieldName}' at index ${index}`);
      }
      await expect(checkbox, `${fieldName} option should be a checkbox`).toHaveAttribute("type", "checkbox");
      await expect(checkbox, `${fieldName} option value mismatch`).toHaveAttribute("value", expectedValue);
    }
  }
  /**
   * Verifies all fields and multi-checkbox options on the
   * Diagnosis & Treatment page.
   *
   * @author Pavan Kumar
   */
  public async verifyDiagnosisTreatmentFields(): Promise<void> {
    await this.verifyFieldsDisplayed("Diagnosis Treatment");
    const diagnosisFields = testData.DIAGNOSISTREATMENTFIELDS as unknown as Record<
      string,
      {
        type: string;
        values?: string[];
      }
    >;
    for (const [fieldName, config] of Object.entries(diagnosisFields)) {
      if (config.type === "multicheckbox") {
        await this.verifyMultiCheckboxOptions(fieldName, config.values ?? []);
      }
    }
  }
}
