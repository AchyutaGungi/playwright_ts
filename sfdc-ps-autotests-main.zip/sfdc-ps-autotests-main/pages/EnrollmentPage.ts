import { testData } from '../utils/common/TestDataUtil.js';
import { Page, FrameLocator, expect, TestInfo } from '@playwright/test';
import { faker } from '@faker-js/faker';
import { fileConfigUtil } from '../utils/common/FileConfigUtil.js';
import { ActionEngineUtil } from '../utils/ui/ActionEngineUtil.js';
import {captureEvidenceScreenshot} from '../utils/ui/ScreenshotsUtil.js'; 

let optionselectDynxpath: string = "//md-option//*[contains(text(),'%s')]";
let patientSearchOptionDynxpath: string = "//mark[text()='%s']";
let patientLinkinResultsPage: string = "//a[text()='%s']";
let prescriberoptionselectDynxpath: string = "//*[contains(@ng-repeat,'state in dialog.states')]//div[text()='%s']";
let enrollmentCompleteoptionselectDynxpath: string = "//*[contains(@ng-repeat,'option in enrollmentDetails.enrollmentComplete')]//div[text()='%s']";
let prescriberaddressoptionselectDynxpath:string = "//*[contains(text(),'%s')]//..//parent::md-radio-button";
let generictextDynxpath: string = "//*[contains(text(),'%s')]";
let servicetypeDynxpath: string = "//h3[text()='%s']/parent::div/preceding-sibling::md-checkbox/div[1]";
const lastnameTextbox = "//*[@ng-model='list.form.lastName']";
const firstNameTextbox = "//*[@ng-model='list.form.firstName']";
const phoneTextbox = "//*[@name='phone']";
const dobTextbox = "//*[@name='birthDate']";
const searchTextbox = "//*[text()='Search']";
const enrollPatientButton = "//*[contains(text(),'Enroll New Patient')]";
const patientsearchframe = "[title='accessibility title']";
const allpatientsLabel = "//h2[text()='All Patients']";
const menuBtn = "//button[@title='Show Navigation Menu']";
const myMessagetext = "//span[@title='My Messages']";
const searchTextboxHomePage = "(//*[text()='Search...'])[1]";
const searchInputTextboxHomePage = "Search...";
const enrollOption = "//span[text()='Enroll Patient']";
const homeOption = "//li//a//span[text()='Home']";
const homeOptionDisplayed = "//a//span[text()='Home']";
const subtabsOnHomePageLinks = "//li[a[@class='tabHeader slds-context-bar__label-action ']]//div[2]//button"
const serviceeligibilitySection = "//md-tab-item//span[text()='Service Eligibility']";
const genderDpDwn = "#patient-gender";
const insuranceRadioBtn = "//div[@class='md-thumb md-ink-ripple']";
const productDpDwn = "#product-0";
const diagnosiscodeTextbox = "#diagnosis-code-0";
const nextBtn = "//button//span[contains(text(),'Next')]";
const choosetypeofserviceLabel = "//h2[text()='Choose Service Type(s):']";
const patientAddressStreettextbox = "#patient-address-street";
const patientaddressapttextbox = "#patient-address-apt";
const patientaddresscitytextbox = "#patient-address-city";
const patientaddressstateDrpdwn = "#patient-address-state";
const patientaddressziptextbox = "#patient-address-zip";
const payerNametextbox = "#payer-name-0";
const showResultsTextLink = "Show more results for ";
const subscriberIdtextbox = "//input[@name='subscriberID-0']";
const subscriberRelationtoPatDrpdwn = "#subscriber-relationship-to-patient-0";
const searchforprescriberlink = "//*[text()='Search for Prescriber']";
const nameandStateradiobtn = "//*[@aria-label='Name and State']/div[1]";
const prescriberFirstName = '[name="firstName"]';
const prescriberLastName = '[name="lastName"]';
const prescriberState = '//md-select[@name="state"]';
const searchprescriberbtn = "//span[text()='Search']/parent::button";
const enrollmentcompletedrpdwn = "//md-select[@name='enrollmentComplete']";
const submitbtn = "//button[@type='submit']";
const selectPrescriberAddressbtn = "//button//*[contains(text(),'Select')]";
const placeofServicedrpdwn = "#prescriber-place-of-service";
const patientIdlink = "PAT-";

export class EnrollmentPage {
    private page: Page;
    private patientFrame: FrameLocator;
    private actionEngine: ActionEngineUtil;
    private testInfo: TestInfo;

    /**
     * This constructor is used to initialize the EnrollmentPage with page and patient frame
     * @param page
     * @author SurendraKumarVetcha
     */
    constructor(page: Page,testInfo: TestInfo) {
        this.page = page;
        this.patientFrame = page.frameLocator(patientsearchframe);
        this.actionEngine = new ActionEngineUtil( this.page);
        this.testInfo = testInfo;
    }

    /**
     * This method is used to select an option from the navigation menu dropdown
     * @param menuoption
     * @author SurendraKumarVetcha
     */
    async selectOptionFromEnrollMenu(menuoption: string) {
        await this.page.waitForLoadState(); 
        await this.handlesubtabs();    
        if (!await this.page.locator(homeOptionDisplayed).isVisible()) {
            await expect(this.page.locator(menuBtn)).toBeVisible();
            await this.page.click(menuBtn);
            await this.page.locator(homeOption).waitFor();
            await this.page.click(homeOption);
            await this.page.locator(myMessagetext).waitFor();
        }
        await this.handlesubtabs();    
        await this.page.locator(menuBtn).waitFor();
        await this.page.click(menuBtn);
        switch (menuoption) {
            case "Enroll Patient":
                await captureEvidenceScreenshot(this.page,this.testInfo,"Menu Option");
                await this.page.locator(enrollOption).first().click();
                break;
        }
        await this.page.waitForTimeout(2000);
    }

    /**
     * This method is used to provide patient data and perform search operation
     * @author SurendraKumarVetcha
     */
    async providePatientDataAndPerformSearchOperation() {
        const firstName = testData.FIRSTNAME || faker.person.firstName();
        fileConfigUtil.insertData('FirstName',firstName);
        const lastName = testData.LASTNAME || faker.person.lastName();
        fileConfigUtil.insertData('LastName',lastName);
        const phoneNumber = testData.PHONENUMBER || faker.string.numeric(10);
        fileConfigUtil.insertData('PhoneNumber',phoneNumber);
        let dob: string = testData.DOB ?? '';
        if (dob.length == 0) {
            dob = faker.date.birthdate({ min: 18, max: 65, mode: 'age' })
                .toLocaleDateString('en-US', {
                    month: '2-digit',
                    day: '2-digit',
                    year: 'numeric'
                });
        }
        fileConfigUtil.insertData('DOB',dob);
        await expect(this.page.locator(patientsearchframe)).toBeVisible({ timeout: 50000 });
        await this.patientFrame.locator(allpatientsLabel).waitFor();
        await this.page.waitForTimeout(2000);
        await this.patientFrame.locator(firstNameTextbox).fill(firstName);
        await this.patientFrame.locator(lastnameTextbox).fill(lastName);
        await this.patientFrame.locator(phoneTextbox).fill(phoneNumber);
        await this.patientFrame.locator(dobTextbox).fill(dob);
        await this.patientFrame.locator(searchTextbox).waitFor({ state: 'visible' });
        await this.patientFrame.locator(searchTextbox).click();
        await this.patientFrame.locator(enrollPatientButton).waitFor({ timeout: 100000 });
    }

    /**
     * This method is used to click on Enroll button and set gender and insurance details
     * @author SurendraKumarVetcha
     */
    async clickOnEnrollButton() {
        await this.patientFrame.locator(enrollPatientButton).scrollIntoViewIfNeeded();
        await this.patientFrame.locator(enrollPatientButton).click();
        await this.patientFrame.locator(serviceeligibilitySection).waitFor({ timeout: 100000 });
        await this.page.waitForTimeout(2000);
        let gender: string = testData.GENDER ?? 'Male';
        await this.patientFrame.locator(genderDpDwn).click();
        const locator = optionselectDynxpath.replace('%s', gender);
        await this.patientFrame.locator(locator).click();
        let insurance: string = testData.INSURRED ?? 'Yes';
        if (insurance == 'No') {
            await this.patientFrame.locator(insuranceRadioBtn).click();
        }
    }

    /**
     * This method is used to set product and diagnosis code
     * @author SurendraKumarVetcha
     */
    async setProductAndDiagnosisCode() {
        await this.patientFrame.locator(productDpDwn).click();
        const dynlocator = optionselectDynxpath.replace('%s', String(testData.PRODUCTNAME));
        console.log(dynlocator)
        //await this.patientFrame.locator(dynlocator).scrollIntoViewIfNeeded();
        await this.patientFrame.locator(dynlocator).click();
        await this.patientFrame.locator(diagnosiscodeTextbox).fill(String(testData.DIAGCODE));
        //await this.page.waitForTimeout(10000);
        const dynlocator2 = generictextDynxpath.replace('%s', String(testData.DIAGFULLCODE));
        if (!await this.patientFrame.locator(dynlocator2).isVisible()) {
            await this.patientFrame.locator(diagnosiscodeTextbox).clear();
            await this.patientFrame.locator(diagnosiscodeTextbox).fill(String(testData.DIAGCODE));
            //await this.page.waitForTimeout(5000);
        }
        await this.patientFrame.locator(dynlocator2).scrollIntoViewIfNeeded();
        await this.patientFrame.locator(dynlocator2).click();
        await this.patientFrame.locator(nextBtn).click();
        await expect(this.patientFrame.locator(choosetypeofserviceLabel)).toBeVisible({ timeout: 50000 });
        //await this.page.waitForTimeout(2000);
    }

    /**
     * This method is used to select Service Type
     * @param servicetype
     * @author SurendraKumarVetcha
     */
    async selectServiceType(servicetype: string) {
        await expect(this.page.locator(patientsearchframe)).toBeVisible({ timeout: 50000 });
        const servicetypelocator = servicetypeDynxpath.replace('%s', servicetype);
        await this.patientFrame.locator(servicetypelocator).click();
    }

    /**
     * This method is used to click on Next button
     * @author SurendraKumarVetcha
     */
    async clickNextButton() {
        await this.patientFrame.locator(nextBtn).click();
    }

     /**
     * This method is used to fill patient address details
     * @author SurendraKumarVetcha
     */
    async fillpatientaddressdetails(){      
        await expect(this.patientFrame.locator(patientAddressStreettextbox)).toBeVisible({timeout:15000});
        await this.patientFrame.locator(patientAddressStreettextbox).fill(String(testData.PATIENTADDRESSSTREET));
        await this.patientFrame.locator(patientaddressapttextbox).fill(String(testData.PATIENTADDRESSAPT));
        await this.patientFrame.locator(patientaddresscitytextbox).fill(String(testData.PATIENTADDRESSCITY));
        await this.patientFrame.locator(patientaddressziptextbox).fill(String(testData.PATIENTADDRESSZIP));
        await this.patientFrame.locator(patientaddressstateDrpdwn).click();
        const dynloc = optionselectDynxpath.replace('%s', String(testData.PATIENTADDRESSSTATE));
        await this.patientFrame.locator(dynloc).click();               
    }

    /**
    * This method is used to fill payer details
    * @author SurendraKumarVetcha
    */
    async setpayerdetails(){        
        await this.patientFrame.locator(payerNametextbox).fill(String(testData.PAYERNAME1));
        await this.page.waitForTimeout(5000);
        await this.patientFrame.locator(subscriberIdtextbox).fill(String(testData.SUBSCRIBERID1));        
        await this.patientFrame.locator(subscriberRelationtoPatDrpdwn).click();
        const dynloc = optionselectDynxpath.replace('%s', String(testData.RELATIONTOPAT));
        await this.patientFrame.locator(dynloc).click();        
    }

    /**
    * This method is used to fill Prescriber details
    * @author SurendraKumarVetcha
    */
    async setprescriberdetails(){          
        await this.patientFrame.locator(searchforprescriberlink).click();  
        await this.patientFrame.locator(nameandStateradiobtn).click();
        await this.patientFrame.locator(prescriberFirstName).fill(String(testData.PRESCRIBERFIRSTNAME));
        await this.patientFrame.locator(prescriberLastName).fill(String(testData.PRESCRIBERLASTNAME));
        await this.patientFrame.locator(prescriberState).click();  
        let dynloc = prescriberoptionselectDynxpath.replace('%s', String(testData.PRESCRIBERSTATE));
        await this.patientFrame.locator(dynloc).click(); 
        await this.patientFrame.locator(searchprescriberbtn).click();
        dynloc = prescriberaddressoptionselectDynxpath.replace('%s', String(testData.PRESCRIBERADDRESS));
        await this.patientFrame.locator(dynloc).click();      
        await this.patientFrame.locator(selectPrescriberAddressbtn).scrollIntoViewIfNeeded();        
        await this.patientFrame.locator(selectPrescriberAddressbtn).click(); 
    } 

    /**
    * This method is used to Enrollment Details
    * @author SurendraKumarVetcha
    */
    async setenrollmentdetails(){  
        await this.patientFrame.locator(enrollmentcompletedrpdwn).waitFor();   
        await this.patientFrame.locator(enrollmentcompletedrpdwn).click();  
        let dynloc = enrollmentCompleteoptionselectDynxpath.replace('%s', String(testData.ENROLLCOMPLETE));
        try{
            await this.patientFrame.locator(dynloc).waitFor({timeout:3000});
            await this.patientFrame.locator(dynloc).click({timeout:3000});
        } catch(error){
            await this.patientFrame.locator(enrollmentcompletedrpdwn).click();  
            await this.patientFrame.locator(dynloc).click();
        }
        await this.patientFrame.locator(placeofServicedrpdwn).click();
        dynloc = optionselectDynxpath.replace('%s', String(testData.PLACEOFSERVICE));
        await this.patientFrame.locator(dynloc).click();
    }

    /**
    * This method is used to Click on Enroll and Capture Patient ID
    * @author SurendraKumarVetcha
    */
    async submitenrollmentandcapturepatientid(){      
        await this.patientFrame.locator(submitbtn).scrollIntoViewIfNeeded();     
        await this.patientFrame.locator(submitbtn).click();   
        await this.patientFrame.getByText(patientIdlink).waitFor();
        fileConfigUtil.insertData('PatientID', await this.patientFrame.getByText(patientIdlink).textContent() ?? '');
    }

    /**
    * This method is handle sub tabs on patient home page
    * @author SurendraKumarVetcha
    */
    async handlesubtabs(){
         try{
            const tabs = this.page.locator(subtabsOnHomePageLinks);
            while ((await tabs.count()) > 0) {
                await tabs.first().click({ timeout: 10000 });
            }
        }catch(error){ }   
        await this.page.waitForTimeout(2000);
    }

    /**
    * This method is used to Search for a Patient
    * @author SurendraKumarVetcha
    */
    async searchforpateintcreated(){
        await this.page.reload();
        await this.page.locator(menuBtn).waitFor();
        await this.page.click(menuBtn);
        await this.page.locator(homeOption).waitFor();
        await this.page.click(homeOption);
        await this.page.locator(myMessagetext).waitFor();
        await this.page.locator(searchTextboxHomePage).click();
        await this.page.getByPlaceholder(searchInputTextboxHomePage).fill(fileConfigUtil.getData("PatientID"));
        let dynxpath = patientSearchOptionDynxpath.replace('%s',fileConfigUtil.getData("PatientID"));
        try{
            await this.page.locator(dynxpath).click({timeout:10000});
        } catch(error){       
            await this.page.getByText(showResultsTextLink).first().click();
            dynxpath = patientLinkinResultsPage.replace('%s',fileConfigUtil.getData("PatientID"));
            await this.page.locator(dynxpath).click();
        }
    }
}