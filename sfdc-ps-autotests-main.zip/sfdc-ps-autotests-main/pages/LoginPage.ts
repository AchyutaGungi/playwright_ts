import { Page, TestInfo, expect } from '@playwright/test';
import { TotpUtil } from '../utils/common/TotpUtil.js';
import { ActionEngineUtil } from '../utils/ui/ActionEngineUtil.js';

const usernametextbox = "#username";
const loginbutton = "#Login";
const passwordtextbox = "#password";
const privacylink = "//a[text()='Privacy']";
const pactlightningheader = "//h1//span[text()='PACT - Lightning']";
const pepHeader = "[title='PEP']";

export class LoginPage {
    private page: Page;
    private actionEngine: ActionEngineUtil;
    private testInfo: TestInfo;

    constructor(page: Page,testInfo: TestInfo) {
        this.page = page;
        this.actionEngine = new ActionEngineUtil(this.page);
        this.testInfo = testInfo;
    }

    /**
     * This method is used to navigate to the application URL and wait for login page to load
     * 
     * @param url
     * @author SurendraKumarVetcha
     */
    async navigatetourl(url: string) {
        await this.page.goto(url);
        console.log("Navigated to URL");
        //await this.page.locator(usernametextbox).waitFor();
    }

    /**
    * This method is used to enter username and password and click on login button
    * 
    * @param username
    * @author SurendraKumarVetcha
    */
    async enterusernameandpassword(username: string) {
        await this.actionEngine.enterText(usernametextbox, process.env[`${username}`] || '',"UserName Textbox");
        await this.actionEngine.clickElement(loginbutton,"Login Button");
        await this.actionEngine.enterText(passwordtextbox, process.env[`${username}Password`] || '',"Password Textbox");
        await this.actionEngine.clickElement(loginbutton,"Login Button");
        //MFA Login
        await this.enterMfaCode(username);
    }

    /**
    * This method is used to validate home page is loaded successfully after login
    * 
    * @author SurendraKumarVetcha
    */
    async validatehomepageload() {
        //await this.page.goto('https://genentech-pps--ppsdev.sandbox.lightning.force.com/lightning');
        await this.page.waitForLoadState();
        await expect.soft(this.page.locator(pactlightningheader)).toBeVisible({ timeout: 30000 });
        await this.page.waitForTimeout(2000);
    }

    /**
    * This method is used to validate privacy page by clicking on privacy link and verifying the new tab
    * 
    * @author SurendraKumarVetcha
    */
    async validateprivacypage() {
        const context = this.page.context();
        const [newPage] = await Promise.all([
            context.waitForEvent('page'),
            this.page.locator(privacylink).click(),
        ]);
        await newPage.waitForLoadState();
        const privacyHeader = await newPage.locator('h1').textContent();
        console.log(privacyHeader);
        await newPage.close();
        await this.page.locator(loginbutton).click();
    }

    /**
    * This method is used to validate home page is loaded successfully after login
    * 
    * @author PavanKumar
    */
    async verifyPEPHomepageIsLoaded() {
        await this.page.waitForLoadState();
        await expect.soft(this.page.locator(pepHeader)).toBeVisible({ timeout: 20000 });
    }

    /**
    * Enters the MFA verification code for the specified user.
    *
    * @param userType - User type used for OTP generation
    * @author Pavan Kumar
    */

    async enterMfaCode(userType: string): Promise<void> {
        const otp = TotpUtil.generateOtp(userType);
        await this.page
            .getByLabel('Verification Code')
            .fill(otp);
        await this.page
            .getByRole('button', { name: 'Verify' })
            .click();
    }

}