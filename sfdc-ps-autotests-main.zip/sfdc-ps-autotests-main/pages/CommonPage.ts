import { Page, expect, TestInfo } from "@playwright/test";
import { ActionEngineUtil } from "../utils/ActionEngineUtil.js";

const productNameDynXpath: string = "//*[@data-label='%s']";
const searchResultDynXpath: string = "//a[contains(text(),'%s')]";
const appLauncher = "//button[normalize-space(.)='App Launcher']";
const searchappsanditems = "//input[@placeholder='Search apps and items...']";
const newBtn = "a[title='New']";
const searchInput = "input[placeholder='Search this list...']";
const setupIcon = "//lightning-icon[@icon-name='utility:setup']";
const setup = "#related_setup_app_home";
const quickFind = "//input[@placeholder='Quick Find']";
const users = "(//mark[text()='Users'])[2]";
const globalSearch = "//input[@placeholder='Search Setup']";
const login = "(//input[@title='Login'])[1]";
const loginFrameXpath: string = "//iframe[contains(@title,'User: %s')]";
const userLinkXpath: string = "//a[contains(@class,'setupLink') and normalize-space()='%s']";

export class CommonPage {
  private page: Page;
  private actionEngine: ActionEngineUtil;
  private testInfo: TestInfo;

  /**
   * This constructor is used to initialize the EnrollmentOcrevusPage with page
   * @param page
   * @author SurendraKumarVetcha
   */
  constructor(page: Page, testInfo: TestInfo) {
    this.page = page;
    this.actionEngine = new ActionEngineUtil(this.page);
    this.testInfo = testInfo;
  }
  public setPage(page: Page): void {
    this.page = page;
    this.actionEngine = new ActionEngineUtil(page);
  }

  /**
   * This method is used to click on AppLauncher
   * @author PavanKumar
   */
  async clickAppLauncher() {
    await this.page.waitForTimeout(2000);
    await this.page.locator(appLauncher).click();
    await this.page.waitForTimeout(2000);
  }

  /**
   * This method is used to select Product from Applauncher
   * @author PavanKumar
   */
  async selectProductFromApplauncher(product: string): Promise<void> {
    await this.actionEngine.waitForElementVisible(searchappsanditems);
    await this.page.locator(searchappsanditems).click();
    await this.page.locator(searchappsanditems).fill(product);
    const dynxpath = productNameDynXpath.replace("%s", product);
    await this.page.locator(dynxpath).waitFor({ state: "visible" });
    await this.page.locator(dynxpath).click();
  }

  /**
   * This method is used to click on New button
   * @author PavanKumar
   */
  async clickNewButton() {
    await this.page.locator(newBtn).filter({ visible: true }).first().click();
  }

  /**
   * Search and select record from list.
   * @param recordName
   * @author Pavan Kumar
   */
  async searchAndSelectRecord(recordName: string) {
    await this.page.locator(searchInput).fill(recordName);
    await this.page.keyboard.press("Enter");
    const recordLink = this.page.locator(searchResultDynXpath.replace("%s", recordName));
    await expect(recordLink).toBeVisible();
    await recordLink.click();
  }

  /**
   * UThis method is used to click on setup Icon
   * @param userName
   * @author Supriya Palle
   */
  public async clickOnSetupIconAndLoginAs(userName: string): Promise<void> {
    await this.actionEngine.waitForElementVisible(setupIcon);
    await this.actionEngine.clickElement(setupIcon, "Clicked on SetupIcon");
    const existingPages = this.page.context().pages();
    await this.actionEngine.waitForElementVisible(setup);
    await this.actionEngine.clickElement(setup, "Clicked on Setup Value");
    // Wait for Setup tab to open
    await this.page.waitForTimeout(5000);
    const allPages = this.page.context().pages();
    const setupPage = allPages.find((page) => !existingPages.includes(page));
    if (!setupPage) {
      throw new Error(`Setup page not found. Total pages: ${allPages.length}`);
    }
    await setupPage.bringToFront();
    await setupPage.waitForLoadState("domcontentloaded");
    // Work in Setup tab
    await setupPage.locator(quickFind).fill("Users");
    await setupPage.locator(quickFind).press("Enter");
    await setupPage.locator(users).click();
    await setupPage.locator(globalSearch).fill(userName);
    const userLink = userLinkXpath.replace("%s", userName);
    const option = setupPage.locator(userLink);
    await option.waitFor({ state: "visible" });
    await option.click({ force: true });
    await option.click();
    const frameXpath = loginFrameXpath.replace("%s", userName);
    const loginBtn = setupPage.frameLocator(frameXpath).locator(login);
    await loginBtn.waitFor({ state: "visible" });
    await loginBtn.click();
    this.page = setupPage;
    // Back to original tab
    // await parentPage.bringToFront();
  }
}
