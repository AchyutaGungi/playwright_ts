import { testData } from "../utils/common/TestDataUtil.js";
import { Page, FrameLocator, expect, TestInfo } from "@playwright/test";
import { faker } from "@faker-js/faker";
import { fileConfigUtil } from "../utils/common/FileConfigUtil.js";
import { ActionEngineUtil } from "../utils/ui/ActionEngineUtil.js";
import { captureEvidenceScreenshot } from "../utils/ui/ScreenshotsUtil.js";

const subtabsOnHomePageLinks =
  "//li[a[@class='tabHeader slds-context-bar__label-action ']]//div[2]//button";
const appLauncher =
  "//button[contains(@class,'slds-button slds-context-bar__button')]";
const searchTextbox = "//input[@placeholder='Search apps and items...']";
const newButton =
  "//button[normalize-space()='New'] | //div[normalize-space()='New']";
const nextButton = "//span[normalize-space()='Next']";
const prescriberFirstName = '[name="firstName"]';
const prescriberLastName = '[name="lastName"]';
const statusDropdown = "//label[text()='Status']/following::button[1]";
const saveButton = "//button[text()='Save']";
const patientNameValue =
  "//slot[@name='primaryField']//lightning-formatted-name";
const careProgramEnrolleesNew =
  "//span[text()='Care Program Enrollees']//following::ul[1]";
const careProgrameEnrolleeName = "//input[@name='Name']";
const careProgramValue = "//input[@aria-label='Care Program']";
const selectButton = "//button[text()='Select']";
const authorizationFormConsents =
  "//span[text()='Authorization Form Consents']//following::li[1]";
const consentType = "//input[@aria-label='Consent Type']";
let optionXpath: string =
  "//lightning-base-combobox-item[contains(@class,'slds-media slds-listbox__option')and normalize-space()='%s']";
let accountTypeDynxpath: string = "//span[text()='%s']";
let accountDynxpath: string = "(//*[contains(text(),'%s')])[2]";
const authorizationForm = "//input[@aria-label='Authorization Form']";
const authorizationFormText = "//input[@aria-label='Authorization Form Text']";
const consentGiver = "//input[@aria-label='Consent Giver']";
const consentStartDate = "//input[@name='ConsentStartDate_PEP__c']";
const name = "//input[@name='Name']";
const authorizationCareProgramName =
  "//slot[@name='primaryField']//lightning-formatted-text";
const careProgramEnrolleName =
  "//slot[@name='primaryField']//lightning-formatted-text";
const closeCareProgramEnrolle =
  "(//button[contains(@title,'Care Program Enrollee')])[2]";
const closeAuthorizationForm =
  "(//button[contains(@title,'Authorization Form Consent')])[2]";
let productNameDynXpath: string = "//*[@data-label='%s']";
const careProgramStartDate =
  "//span[text()='Start Date']/ancestor::label/following::input[1]";
const careProgramName =
  "//span[text()='Name']/ancestor::label/following::input[1]";
const careProgramSaveButton = "//span[text()='Save']";
let authorizationFieldDynXpath: string =
  "//span[text()='%s']/ancestor::records-record-layout-item//*[self::a or self::lightning-formatted-text][1]";
let requiredFieldError =
  "//label[contains(.,'%s')]/following::div[contains(@class,'slds-form-element__help') and normalize-space()][1]";
const nameFieldError =
  "//input[@name='Name']/ancestor::*[contains(@class,'slds-form-element')]//div[contains(@class,'slds-form-element__help')]";
let expiredRecord: string =
  "//tr[td//*[normalize-space()='%s'] and td//*[normalize-space()='Expired']]";
let dynamicTabs: string = "//a[text()='%s']";
const careProgramEnrolleLinks =
  "//span[text()='Care Program Enrollees']/ancestor::article//tbody/tr//th//a";
const preferencesPencilIcon =
  "//records-record-layout-item[@field-label='Preferred Language']//button[contains(@class,'slds-button_icon')]";
const preferedLanguage = "(//span[text()='Preferred Language'])[2]";
let dropdownByFieldPreferences: string = "//button[@aria-label='%s']";
let dropdownOptionPrefrences: string =
  "//*[contains(@class,'listbox')]//*[@role='option'][contains(normalize-space(.),'%s')]";
let preferencesValue: string =
  "//span[normalize-space()='%s']/ancestor::div[contains(@class,'slds-form-element')]//lightning-formatted-text";
const consentStatusDropdown =
  "//label[text()='Consent Status']/following::button[1]";
let rowLink: string = "%s//th//a";

export class PatientAccountFormPage {
  private page: Page;
  private actionEngine: ActionEngineUtil;
  private testInfo: TestInfo;

  constructor(page: Page, testInfo: TestInfo) {
    this.page = page;
    this.actionEngine = new ActionEngineUtil(this.page);
    this.testInfo = testInfo;
  }
  public setPage(page: Page): void {
    this.page = page;
    this.actionEngine = new ActionEngineUtil(page);
  }
  /**
   * This method is used to select an option from the navigation menu dropdown
   * @param menuoption
   * @author Supriya Palle
   */
  async selectOptionFromMenu(menuoption: string): Promise<void> {
    await this.actionEngine.clickElement(searchTextbox, "Click on Search");
    await this.actionEngine.enterText(
      searchTextbox,
      menuoption,
      "Enter Menu Option Value",
    );
    const dynxpath = productNameDynXpath.replace("%s", menuoption);
    await this.page.locator(dynxpath).waitFor({ state: "visible" });
    await this.actionEngine.clickElement(dynxpath, "Click on Product");
    if (menuoption.trim() === "PEP") {
      let count = await this.page.locator(subtabsOnHomePageLinks).count();
      for (let i = 0; i < count; i++) {
        const currentCount = await this.page
          .locator(subtabsOnHomePageLinks)
          .count();
        await this.page.locator(subtabsOnHomePageLinks).first().click();
        await expect(this.page.locator(subtabsOnHomePageLinks)).toHaveCount(
          currentCount - 1,
        );
      }
      await this.page.waitForLoadState();
    }
  }
  /**
   * This method is used to select an type from the AccountCreation
   * @param servicetype
   * @author Supriya Palle
   */
  async selectAccountType(servicetype: string) {
    await this.page.waitForLoadState();
    await this.actionEngine.clickElement(newButton, "Click on New Button");
    const accounttypelocator = accountTypeDynxpath.replace("%s", servicetype);
    await this.actionEngine.clickElement(
      accounttypelocator,
      "Click on account type ",
    );
    if (servicetype == "Alternate Contact") {
      const accountlocator = accountDynxpath.replace("%s", servicetype);
      await this.actionEngine.clickElement(
        accountlocator,
        "Click on account type ",
      );
      await expect(this.page.locator(accountlocator)).toBeChecked();
    }
    await expect(this.page.locator(accounttypelocator)).toBeChecked();
    //added screenshot to take after selecting account type
    await captureEvidenceScreenshot(
      this.page,
      this.testInfo,
      "Clicked on account type",
    );
    await this.actionEngine.waitForElementVisible(nextButton);
    await this.actionEngine.clickElement(nextButton, "Click on next button ");
    await this.actionEngine.waitForElementVisible(prescriberFirstName);
  }
  /**
   * This method is used to provide patient data and perform search operation
   * @author Supriya Palle
   */
  async providePatientData() {
    const firstName = testData.FIRSTNAME || faker.person.firstName();
    fileConfigUtil.insertData("FirstName", firstName);
    const lastName = testData.LASTNAME || faker.person.lastName();
    fileConfigUtil.insertData("LastName", lastName);
    // Combine first + last name
    const fullName = `${firstName} ${lastName}`;
    fileConfigUtil.insertData("FullName", fullName);
    await expect
      .soft(this.page.locator(prescriberFirstName))
      .toBeVisible({ timeout: 30000 });
    await this.actionEngine.enterText(
      prescriberFirstName,
      firstName,
      "FirstName Textbox",
    );
    await this.actionEngine.enterText(
      prescriberLastName,
      lastName,
      "LastName Textbox",
    );
    console.log(`Patient full name entered: ${fullName}`);
  }
  /**
   * This method is used to select status of Patient
   * @param statusValue
   * @author Supriya Palle
   */
  async selectPatientStatus(statusValue: string) {
    const selectedStatus = statusValue ?? "--None--";
    await this.actionEngine.clickElement(statusDropdown, "Status Dropdown");
    const dynLocator = optionXpath.replace("%s", selectedStatus);
    await this.actionEngine.clickElement(dynLocator, "Status Value");
    await this.page.waitForLoadState();
  }
  /**
   * This method is used to Save
   * @author Supriya Palle
   */
  async clickOnSave() {
    await this.actionEngine.clickElement(saveButton, "Save Button");
    await this.page.waitForLoadState();
  }
  /**
   * This method validates that the created patient Name
   * @author Supriya Palle
   */
  async validatePatientName() {
    const expectedFullName = fileConfigUtil.getData("FullName");
    await this.actionEngine.waitForElementVisible(patientNameValue);
    await this.actionEngine.verifyText(
      patientNameValue,
      expectedFullName,
      "Patient Name",
    );
    console.log(`Validated patient name: ${expectedFullName}`);
    await this.page.waitForLoadState();
  }
  /**
   * This method is used to select new button of Care Program Enrolle
   * @author Supriya Palle
   */
  async selectNewCareProgramEnrollees() {
    await this.actionEngine.waitForElementVisible(careProgramEnrolleesNew);
    await this.actionEngine.clickElement(careProgramEnrolleesNew, "New Button");
  }
  /**
   * This method is used to select new button of Care Program Enrolle
   * @author Supriya Palle
   */
  async provideCareProgramEnrolleesData() {
    for (let i = 1; i <= 2; i++) {
      const firstName = fileConfigUtil.getData("FirstName");
      await this.selectNewCareProgramEnrollees();
      const enrolleeName = `${firstName}CPE${i}`;
      await this.actionEngine.waitForElementVisible(careProgrameEnrolleeName);
      await this.actionEngine.enterText(
        careProgrameEnrolleeName,
        enrolleeName,
        "Enrolle Name",
      );
      await this.actionEngine.clickElement(
        careProgramValue,
        "Care Program Value",
      );
      await this.page.getByText("New Care Program", { exact: true }).click();
      const careProgramNames = `${firstName}CPEName${i}`;
      await this.actionEngine.enterText(
        careProgramName,
        careProgramNames,
        "Care Program Name",
      );
      const currentDate = new Date().toLocaleDateString("en-US");
      await this.actionEngine.enterText(
        careProgramStartDate,
        currentDate,
        "Care Program Start Date Field",
      );
      await this.actionEngine.clickElement(
        careProgramSaveButton,
        "Care Program save button",
      );
      await this.clickOnSave();
      //added screenshot to take after selecting account type
      await captureEvidenceScreenshot(
        this.page,
        this.testInfo,
        "Created Care Program Enrolle",
      );
      await this.validatePatientCareProgramEnrolle(enrolleeName);
    }
  }
  /**
   * This method is used to select new button of Authorization Form Consents
   * @author Supriya Palle
   */
  async selectNewAuthorizationFormConsents() {
    await this.page.waitForLoadState();
    await this.actionEngine.waitForElementVisible(authorizationFormConsents);
    const locator = this.page.locator(authorizationFormConsents);
    while ((await locator.count()) === 0) {
      await this.page.mouse.wheel(0, 1000);
      await this.page.waitForTimeout(500);
    }
    await locator.scrollIntoViewIfNeeded();
    await locator.click({ force: true });
  }
  /**
   * This method is used to Consent Type in Authorization Form Consent
   * @param consent
   * @author Supriya Palle
   */
  async selectConsentType(consent: string) {
    await this.actionEngine.enterText(
      consentType,
      consent,
      "Consent Type Field",
    );
    await this.actionEngine.pressKey("Enter");
    // Wait for lookup suggestions
    const showMoreResults = this.page.getByText(
      `Show more results for "${consent}"`,
      { exact: true },
    );
    await showMoreResults.waitFor({ state: "visible" });
    await showMoreResults.click();
    const row = this.page.locator("tbody tr").filter({
      has: this.page.getByText(consent, { exact: true }),
    });
    await row.locator("label.slds-radio__label").first().click();
    await this.page.getByRole("button", { name: "Select" }).click();
  }
  /**
   * This method is used to fill required details in Authorization Form Consent
   * @author Supriya Palle
   */
  async provideAuthorizationFormDetails() {
    const consentGiverName = fileConfigUtil.getData("FullName");
    await this.actionEngine.enterText(
      consentGiver,
      consentGiverName,
      "Consent Giver Field",
    );
    await this.actionEngine.clickElement(
      consentGiver,
      "click the authorization text field",
    );
    const showMoreResults = this.page.getByText(
      `Show more results for "${consentGiverName}"`,
      { exact: true },
    );
    await showMoreResults.waitFor({ state: "visible" });
    await showMoreResults.click();
    const row = this.page.locator("tbody tr").filter({
      has: this.page.getByText(consentGiverName, { exact: true }),
    });
    await row.locator("label.slds-radio__label").click();
    await this.page.getByRole("button", { name: "Select" }).click();
    const currentDate = new Date().toLocaleDateString("en-US");
    await this.actionEngine.enterText(
      consentStartDate,
      currentDate,
      "Consent Start Date Field",
    );
    const authorizationName = faker.person.firstName();
    fileConfigUtil.insertData("AuthorizationName", authorizationName);
    await this.actionEngine.enterText(
      name,
      authorizationName,
      "FirstName Textbox",
    );
    //added screenshot to take after selecting new button
    await captureEvidenceScreenshot(
      this.page,
      this.testInfo,
      "Clciked on New and Entered the required details in Authorization Form Consent",
    );
    await this.clickOnSave();
  }
  /**
   * This method validates that the created patient form Name
   * @author Supriya Palle
   */
  async validatePatientCareProgramEnrolle(expectedName: string) {
    await this.actionEngine.verifyText(
      careProgramEnrolleName,
      expectedName,
      "Patient Care Program Enrollee Name",
    );
    console.log(
      `Validated Patient Care Program Enrollee Name: ${expectedName}`,
    );
    await this.actionEngine.clickElement(
      closeCareProgramEnrolle,
      "Close care program page",
    );
  }
  /**
   * This method is used to select Authorization form name
   * @param authorization
   * @author Supriya Palle
   */
  async selectAuthorizationForm(authorization: string) {
    await this.actionEngine.enterText(
      authorizationForm,
      authorization,
      "Authorization Form Field",
    );
    await this.actionEngine.clickElement(
      authorizationForm,
      "click the authorization text field",
    );
    const showMoreResults = this.page.getByText(
      `Show more results for "${authorization}"`,
      { exact: true },
    );
    await showMoreResults.waitFor({ state: "visible" });
    await showMoreResults.click();
    const row = this.page.locator("tbody tr").filter({
      has: this.page.getByText(authorization, { exact: true }),
    });
    await row.locator("label.slds-radio__label").click();
    await this.page.getByRole("button", { name: "Select" }).click();
  }
  /**
   * This method is used to select Authorization form  Text name
   * @param authorizationText
   * @author Supriya Palle
   */
  async selectAuthorizationFormText(authorizationText: string) {
    await this.actionEngine.enterText(
      authorizationFormText,
      authorizationText,
      "Authorization Form Text Field",
    );
    await this.actionEngine.clickElement(
      authorizationFormText,
      "click the authorization text field",
    );
    const showMoreResults = this.page.getByText(
      `Show more results for "${authorizationText}"`,
      { exact: true },
    );
    await showMoreResults.waitFor({ state: "visible" });
    await showMoreResults.click();
    const row = this.page.locator("tbody tr").filter({
      has: this.page.getByText(authorizationText, { exact: true }),
    });
    await row.locator("label.slds-radio__label").click();
    await this.page.getByRole("button", { name: "Select" }).click();
  }
  /**
   * This method is used to create Authorization Form Consent
   * @param consentType
   * @param authorizationFormName
   * @param authorizationFormTextName
   * @author Supriya Palle
   */
  async createAuthorizationFormConsent(
    consentType: string,
    authorizationFormName: string,
    authorizationFormTextName: string,
  ) {
    await this.selectNewAuthorizationFormConsents();
    await this.selectConsentType(consentType);
    await this.selectAuthorizationForm(authorizationFormName);
    await this.selectAuthorizationFormText(authorizationFormTextName);
    await this.provideAuthorizationFormDetails();
  }
  /**
   * This method validates that the created patient form Name
   * @author Supriya Palle
   */
  async validatePatientAuthorizationForm(
    consentType: string,
    authorizationForm: string,
    authorizationFormText: string,
  ) {
    //Kept this code may usefull future
    // const expectedName = fileConfigUtil.getData("AuthorizationName");
    // await this.actionEngine.verifyText(
    //   authorizationCareProgramName,
    //   expectedName,
    //   "Patient Authorization Form Name",
    // );
    // console.log(`Validated Patient Authorization Form name: ${expectedName}`);
    const patientName = fileConfigUtil.getData("FullName");
    const currentDate = new Date().toLocaleDateString("en-US");
    const validations = [
      { field: "Consent Type", value: consentType },
      { field: "Authorization Form", value: authorizationForm },
      { field: "Authorization Form Text", value: authorizationFormText },
      { field: "Consent Giver", value: patientName },
      { field: "Patient Name", value: patientName },
      { field: "Consent Start Date", value: currentDate },
    ];
    for (const item of validations) {
      const locator = authorizationFieldDynXpath.replace("%s", item.field);
      await this.actionEngine.verifyText(locator, item.value, item.field);
    }
    await this.actionEngine.verifyText(
      authorizationFieldDynXpath.replace("%s", "Consent Status"),
      String(testData.CONSENTSTATUS),
      "Consent Status",
    );
    await this.actionEngine.verifyText(
      authorizationFieldDynXpath.replace("%s", "Source"),
      String(testData.SOURCE),
      "Source",
    );
    await this.actionEngine.verifyText(
      authorizationFieldDynXpath.replace("%s", "Program Name"),
      String(testData.PROGRAMNAME),
      "Program Name",
    );
    //added screenshot to take after validating
    await captureEvidenceScreenshot(
      this.page,
      this.testInfo,
      "Verified the entered details",
    );
    console.log("Authorization Form Consent validated successfully");
    await this.actionEngine.clickElement(
      closeAuthorizationForm,
      "Close Form Page",
    );
  }
  /**
   * Verifies that the required field error message contains the expected text.
   * @param fieldName Name of the field whose error message is validated.
   * @param expectedMessage Expected error message text.
   * @author Supriya Palle
   */
  async verifyRequiredFieldError(
    fieldName: string,
    expectedMessage: string,
  ): Promise<void> {
    const locator = requiredFieldError.replace("%s", fieldName);
    await this.actionEngine.verifyContainsText(
      locator,
      expectedMessage,
      `${fieldName} Error`,
    );
  }
  /**
   * This method validates that the required field error message
   * @author Supriya Palle
   */
  async validateMandatoryFieldErrors(): Promise<void> {
    await this.actionEngine.clickElement(saveButton, "Save Button");
    const validations = [
      { field: "Consent Type", error: "Complete this field." },
      { field: "Consent Giver", error: "Complete this field." },
      { field: "Authorization Form Text", error: "Complete this field." },
      { field: "Patient Name", error: "Complete this field." },
      { field: "Name", error: "Complete this field." },
      { field: "Consent Start Date", error: "Complete this field with format" },
    ];
    for (const validation of validations) {
      let locator: string;
      if (validation.field === "Name") {
        locator = nameFieldError;
      } else {
        locator = requiredFieldError.replace("%s", validation.field);
      }
      await this.actionEngine.verifyContainsText(
        locator,
        validation.error,
        `${validation.field} Error`,
      );
    }
  }
  /**
   * Verifies that the expired consent status is visible and navigate to that page.
   * @param consentType
   * @author Supriya Palle
   */
  async validateExpiredConsentVisible(consentType: string): Promise<void> {
    const rowLocator = expiredRecord.replace("%s", consentType);
    await expect(this.page.locator(rowLocator)).toBeVisible();
    //added screenshot to take 'Expired Consent is visible
    await captureEvidenceScreenshot(
      this.page,
      this.testInfo,
      "Expired Consent is visible in Authorization Form Table",
    );
    const accountLink = rowLink.replace("%s", rowLocator);
    await this.actionEngine.clickElement(
      accountLink,
      "${consentType} Expired Record",
    );
  }
  /**
   * This method verifies the existing consent status and Expired Date.
   * @author Supriya Palle
   */
  async validateExistingConsentDetails() {
    const expectedDate = new Date().toLocaleDateString("en-US", {
      timeZone: "America/Los_Angeles",
    });
    await this.validateExpiredConsentVisible(String(testData.CONSENTTYPE));
    await this.actionEngine.verifyText(
      authorizationFieldDynXpath.replace("%s", "Consent Status"),
      String(testData.CONSENTSTATUSEXISTINGCONSENT),
      "Consent Status",
    );
    await this.actionEngine.verifyText(
      authorizationFieldDynXpath.replace("%s", "Consent Expiry Date"),
      expectedDate,
      "Consent Expiry Date",
    );
  }
  /**
   * This method is used to add a preferences
   * @author Supriya Palle
   */
  public async addPrefreencesDetails(
    preferences: Record<string, string>,
  ): Promise<void> {
    await this.actionEngine.scrollToElement(preferencesPencilIcon);
    await this.actionEngine.clickElement(
      preferencesPencilIcon,
      "Edit Pencil Icon",
    );
    await this.selectPreferencesDropdownValue(
      "Preferred Language",
      String(preferences.PREFERREDLANGUAGE),
    );
    await this.selectPreferencesDropdownValue(
      "Preferred Time of Day",
      String(preferences.PREFERREDTIMEOFDAY),
    );
    await this.selectPreferencesDropdownValue(
      "Preferred Communication Channel",
      String(preferences.PREFERREDCOMMUNICATIONCHANNEL),
    );
    await this.selectPreferencesDropdownValue(
      "Preferred Day of Week",
      String(preferences.PREFERREDDAYOFWEEK),
    );
    await this.selectPreferencesDropdownValue(
      "Time Zone",
      String(preferences.TIMEZONE),
    );
  }
  /**
   * Select value from  dropdown for preferences.
   *
   * @param fieldName Dropdown field name
   * @param value Value to select
   * @author Supriya Palle
   */
  async selectPreferencesDropdownValue(
    fieldName: string,
    value: string,
  ): Promise<void> {
    const dropdown = dropdownByFieldPreferences.replace("%s", fieldName);
    const option = dropdownOptionPrefrences.replace("%s", value);
    await this.actionEngine.clickElement(dropdown, `${fieldName} Dropdown`);
    await this.page.locator(option).scrollIntoViewIfNeeded();
    await this.actionEngine.clickElement(option, `${value} Option`);
  }
  /**
   * Update preferences using test data
   * @author Supriya Palle
   */
  public async updateAccountPreferences(preferenceName: string): Promise<void> {
    const preferences = (testData as any)[preferenceName];
    await this.addPrefreencesDetails(preferences);
    await this.clickOnSave();
  }
  /**
   * This method is used to select tabs in Account
   * @param tabValue
   * @author Supriya Palle
   */
  async selectTab(tabValue: string) {
    const dynLocator = dynamicTabs.replace("%s", tabValue);
    await this.actionEngine.clickElement(dynLocator, "Click tab");
    await this.page.waitForLoadState();
  }
  /**
   * This method is used to validate all the careprograms
   * @param preferences
   * @author Supriya Palle
   */
  public async validateAllCarePrograms(
    preferences: Record<string, string>,
  ): Promise<void> {
    const count = await this.page.locator(careProgramEnrolleLinks).count();
    for (let i = 0; i < count; i++) {
      const link = this.page.locator(careProgramEnrolleLinks).nth(i);
      const name = await link.textContent();
      await link.click();
      console.log(`Validating ${name}`);
      // validations
      await this.validatePreferences(preferences);
      await this.actionEngine.clickElement(
        closeCareProgramEnrolle,
        "Close care program page",
      );
    }
  }
  /**
   * This method is used to validate all preferences
   * @author Supriya Palle
   */
  public async validatePreferences(
    preferences: Record<string, string>,
  ): Promise<void> {
    const fieldMappings = {
      PREFERREDLANGUAGE: "Preferred Language",
      PREFERREDTIMEOFDAY: "Preferred Time of Day",
      PREFERREDCOMMUNICATIONCHANNEL: "Preferred Communication Channel",
      PREFERREDDAYOFWEEK: "Preferred Day of Week",
      TIMEZONE: "Time Zone",
    };
    await this.page.evaluate(() => {
      window.scrollTo(0, document.body.scrollHeight);
    });
    for (const [key, fieldName] of Object.entries(fieldMappings)) {
      const locator = preferencesValue.replace("%s", fieldName);
      await this.actionEngine.verifyText(
        locator,
        String(preferences[key]),
        fieldName,
      );
    }
    //added screenshot to take after selecting account type
    await captureEvidenceScreenshot(
      this.page,
      this.testInfo,
      "Validated the added/updated Preferences",
    );
  }
  /**
   * Validate preferences using test data
   * @author Supriya Palle
   */
  public async validateAccountPreferences(
    preferenceName: string,
  ): Promise<void> {
    const preferences = (testData as any)[preferenceName];
    await this.validateAllCarePrograms(preferences);
  }
  /**
   * Validate all the care program preferences using test data
   * @author Supriya Palle
   */
  public async validateAllCareProgramPreferences(): Promise<void> {
    const count = await this.page.locator(careProgramEnrolleLinks).count();
    for (let i = 0; i < count; i++) {
      const link = this.page.locator(careProgramEnrolleLinks).nth(i);
      const name = await link.textContent();
      await link.click();
      console.log(`Validating ${name}`);
      // Validate labels
      await this.validatePreferenceFieldsPresent();
      //added screenshot to take after selecting account type
      await captureEvidenceScreenshot(
        this.page,
        this.testInfo,
        "Validated the Prefrences",
      );
      await this.actionEngine.clickElement(
        closeCareProgramEnrolle,
        "Close care program page",
      );
    }
  }
  /**
   * Validate preferences fields are present
   * @author Supriya Palle
   */
  public async validatePreferenceFieldsPresent(): Promise<void> {
    const fieldMappings = {
      PREFERREDLANGUAGE: "Preferred Language",
      PREFERREDTIMEOFDAY: "Preferred Time of Day",
      PREFERREDCOMMUNICATIONCHANNEL: "Preferred Communication Channel",
      PREFERREDDAYOFWEEK: "Preferred Day of Week",
      TIMEZONE: "Time Zone",
    };
    for (const fieldName of Object.values(fieldMappings)) {
      const locator = `//*[normalize-space()='${fieldName}']`;
      await this.actionEngine.isElementVisible(locator);
    }
  }
  /**
   * This method is used to create Authorization Form Consent
   * @param consentType
   * @param authorizationFormName
   * @param authorizationFormTextName
   * @param statusValue
   * @author Supriya Palle
   */
  async createAuthorizationFormConsentWithStatus(
    consentType: string,
    authorizationFormName: string,
    authorizationFormTextName: string,
    statusValue: string,
  ) {
    await this.selectNewAuthorizationFormConsents();
    await this.selectConsentType(consentType);
    await this.selectConsentStatus(statusValue);
    await this.selectAuthorizationForm(authorizationFormName);
    await this.selectAuthorizationFormText(authorizationFormTextName);
    await this.provideAuthorizationFormDetails();
  }
  /**
   * This method validates that the created patient form Name
   * @author Supriya Palle
   */
  async validatePatientAuthorizationFormWithStatus(
    consentType: string,
    authorizationForm: string,
    authorizationFormText: string,
    statusValue: string,
  ) {
    //kept this may useful future
    // const expectedName = fileConfigUtil.getData("AuthorizationName");
    // await this.actionEngine.verifyText(
    //   authorizationCareProgramName,
    //   expectedName,
    //   "Patient Authorization Form Name",
    // );
    // console.log(`Validated Patient Authorization Form name: ${expectedName}`);
    const patientName = fileConfigUtil.getData("FullName");
    const currentDate = new Date().toLocaleDateString("en-US");
    const validations = [
      { field: "Consent Type", value: consentType },
      { field: "Authorization Form", value: authorizationForm },
      { field: "Authorization Form Text", value: authorizationFormText },
      { field: "Consent Giver", value: patientName },
      { field: "Patient Name", value: patientName },
      { field: "Consent Start Date", value: currentDate },
      { field: "Consent Status", value: statusValue },
    ];
    for (const item of validations) {
      const locator = authorizationFieldDynXpath.replace("%s", item.field);
      await this.actionEngine.verifyText(locator, item.value, item.field);
    }
    await this.actionEngine.verifyText(
      authorizationFieldDynXpath.replace("%s", "Source"),
      String(testData.SOURCE),
      "Source",
    );
    await this.actionEngine.verifyText(
      authorizationFieldDynXpath.replace("%s", "Program Name"),
      String(testData.PROGRAMNAME),
      "Program Name",
    );
    //added screenshot to take after validating
    await captureEvidenceScreenshot(
      this.page,
      this.testInfo,
      "Verified the entered details",
    );
    console.log("Authorization Form Consent validated successfully");
    await this.actionEngine.clickElement(
      closeAuthorizationForm,
      "Close Form Page",
    );
  }
  /**
   * Validate Consent Status in Order
   * @author Supriya Palle
   */
  public async validateConsentStatusOrder() {
    const statuses = await this.page
      .locator(
        "//span[contains(text(),'Authorization Form Consents')]/ancestor::article//tbody/tr/td[3]",
      )
      .allInnerTexts();
    console.log("Statuses:", statuses);
    const order: { [key: string]: number } = {
      Active: 1,
      Expired: 2,
      Revoked: 3,
    };
    for (let i = 0; i < statuses.length - 1; i++) {
      const currentStatus = statuses[i]?.trim() || "";
      const nextStatus = statuses[i + 1]?.trim() || "";
      const current = order[currentStatus] ?? 999;
      const next = order[nextStatus] ?? 999;
      expect(
        current,
        `Invalid order: ${currentStatus} appears before ${nextStatus}`,
      ).toBeLessThanOrEqual(next);
    }
    console.log("Consent Statuses are sorted correctly.");
  }
  /**
   * This method is used to select status of Consent
   * @param statusValue
   * @author Supriya Palle
   */
  async selectConsentStatus(statusValue: string) {
    const selectedStatus = statusValue ?? "--None--";
    await this.actionEngine.clickElement(
      consentStatusDropdown,
      "Status Dropdown",
    );
    const dynLocator = optionXpath.replace("%s", selectedStatus);
    await this.actionEngine.clickElement(dynLocator, "Status Value");
    await this.page.waitForLoadState();
  }
}
