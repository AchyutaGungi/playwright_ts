import { When, Then } from "../fixtures.js";

When("Select {string} from naviagtion menu dropdown", async ({ enrollmentPage }, menuoption: string) => {
  await enrollmentPage.selectOptionFromEnrollMenu(menuoption);
});

Then("Provide the patient data", async ({ enrollmentPage }) => {
  await enrollmentPage.providePatientDataAndPerformSearchOperation();
});

Then("Click on Enroll", async ({ enrollmentPage }) => {
  await enrollmentPage.clickOnEnrollButton();
});

Then("Set product and Diagonosiscode", async ({ enrollmentPage }) => {
  await enrollmentPage.setProductAndDiagnosisCode();
});

Then("Select {string} Checkbox", async ({ enrollmentPage }, servicetype: string) => {
  await enrollmentPage.selectServiceType(servicetype);
});

Then("Click on Next", async ({ enrollmentPage }) => {
  await enrollmentPage.clickNextButton();
});

Then("Set Patient address", async ({ enrollmentPage }) => {
  await enrollmentPage.fillpatientaddressdetails();
});

Then("Set Payer Name", async ({ enrollmentPage }) => {
  await enrollmentPage.setpayerdetails();
});

Then("Set Prescriber data", async ({ enrollmentPage }) => {
  await enrollmentPage.setprescriberdetails();
});

Then("Set Enrollment data", async ({ enrollmentPage }) => {
  await enrollmentPage.setenrollmentdetails();
});

Then("Click on Submit Enrollment", async ({ enrollmentPage }) => {
  await enrollmentPage.submitenrollmentandcapturepatientid();
  await enrollmentPage.searchforpateintcreated();
});
