import { When, Then, Given } from "../fixtures.js";

Given("User launches salesforce application", async ({ loginPage }) => {
  await loginPage.navigatetourl(process.env.URL!);
});

When("User enters username and password {string}", async ({ loginPage }, username: string) => {
  await loginPage.enterusernameandpassword(username);
});

Then("User should login successfully", async ({ loginPage }) => {
  await loginPage.validatehomepageload();
});

Then("User Validate Privacy Page", async ({ loginPage }) => {
  await loginPage.validateprivacypage();
});

Given("User launches life sciences cloud salesforce application", async ({ loginPage }) => {
  await loginPage.navigatetourl(process.env.LSCURL!);
});

Then("User should login life sciences cloud salesforce successfully", async ({ loginPage }) => {
  await loginPage.verifyPEPHomepageIsLoaded();
});
