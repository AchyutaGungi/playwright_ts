import { test as base, createBdd } from 'playwright-bdd';
import { EnrollmentPage } from "../pages/EnrollmentPage.js";
import { LoginPage } from "../pages/LoginPage.js"
import { CommonPage } from "../pages/CommonPage.js";
import { ReceivedDocumentPage } from '../pages/ReceivedDocumentPage.js'
import { PatientAccountFormPage } from "../pages/PatientAccountFormPage.js"
import { AccountsPage } from '../pages/AccountsPage.js';
import { ScenarioContext } from '../utils/contexts/ScenarioContext.js';

type PageFixtures = {
    loginPage:LoginPage;
    enrollmentPage:EnrollmentPage;
    commonPage:CommonPage;
    receivedDocumentPage:ReceivedDocumentPage;
    patientAccountFormPage:PatientAccountFormPage;
    accountsPage :AccountsPage;   
    scenarioContext:ScenarioContext;
}

export const test = base.extend<PageFixtures>({
    loginPage: async ({ page }, use, testinfo) => {
        await use(new LoginPage(page,testinfo));
    },
    enrollmentPage : async({page},use, testinfo)=>{
       await use(new EnrollmentPage(page,testinfo));
    },
     commonPage : async({page},use, testinfo)=>{
       await use(new CommonPage(page,testinfo));
    },
     receivedDocumentPage : async({page},use, testinfo)=>{
       await use(new ReceivedDocumentPage(page,testinfo));
    },
    patientAccountFormPage : async({page},use, testinfo)=>{
       await use(new PatientAccountFormPage(page,testinfo));
    },
    accountsPage : async({page},use, testinfo)=>{
       await use(new AccountsPage(page,testinfo));
    },
    scenarioContext: async ({}, use) => {
    await use(new ScenarioContext());
}
});

export const { Given, When, Then, Before, AfterStep, BeforeStep } = createBdd(test);