import { Before, BeforeStep, AfterStep } from "./fixtures.js";
import { captureScreenshotafterstep } from "../utils/ui/ScreenshotsUtil.js";
import { loadAndSetTestData } from "../utils/common/TestDataUtil.js";
import path from "path";
import { fileConfigUtil } from "../utils/common/FileConfigUtil.js";

const env = process.env.ENV || "UAT";

Before(async function ({ $testInfo, $tags }) {
  console.log(`■ Scenario Started: ${$testInfo.title}`);
  const normalizedPath = $testInfo.file.replace(/\\/g, "/");
  const pathParts = normalizedPath.split("/");
  const featuresIndex = pathParts.findIndex((part) => part.toLowerCase() === "features");
  const squadName =
    featuresIndex >= 0 && pathParts.length > featuresIndex + 1 ? (pathParts[featuresIndex + 1] ?? "demo") : "demo";
  const fileName = path.basename($testInfo.file);
  const featureFile = fileName.replace(".feature.spec.js", "");
  fileConfigUtil.createRunTimeFile("./test-results/runtimepropertyfiles", featureFile);
  if ($tags.includes("@api")) {
    console.log("API Scenarios Started");
  } else {
    loadAndSetTestData(env, featureFile, squadName);
  }
});

BeforeStep(async function ({ $step }) {
  console.log(`■ Step Started: ${$step.title}`);
});

AfterStep({ tags: "not @api" }, async function ({ page, $testInfo, $step }) {
  console.log(`■ Step Finished: ${$step.title} - ${$testInfo.status}`);
  const activePage = page.context().pages().at(-1) ?? page; // Get Last Tab Opened
  await captureScreenshotafterstep(activePage!, $testInfo, $step.title);
});
