import { When, Then } from "../fixtures.js";

When("Click on App Launcher", async ({ commonPage }) => {
  await commonPage.clickAppLauncher();
});

When("Search {string} from App Launcher and Select that Product", async ({ commonPage }, product: string) => {
  await commonPage.selectProductFromApplauncher(product);
});

When("Click on New Button", async ({ commonPage }) => {
  await commonPage.clickNewButton();
});

When("User searches and selects {string}", async ({ commonPage }, recordName) => {
  await commonPage.searchAndSelectRecord(recordName);
});

When("User creates a new Received Document with valid details", async ({ receivedDocumentPage }) => {
  await receivedDocumentPage.fillReceivedDocumentDetails();
});

When("User uploads document {string}", async ({ receivedDocumentPage }, fileName) => {
  await receivedDocumentPage.uploadDocument(fileName);
});

When("Click on {string}", async ({ receivedDocumentPage }, tabName) => {
  await receivedDocumentPage.clickTab(tabName);
});

When("User selects classification as {string}", async ({ receivedDocumentPage }, classification) => {
  await receivedDocumentPage.selectClassifications(classification);
});

When("Click on Next Button", async ({ receivedDocumentPage }) => {
  await receivedDocumentPage.clickNextButton();
});

When("User selects Document Sub-Type as {string}", async ({ receivedDocumentPage }, documentSubType) => {
  await receivedDocumentPage.selectDocumentSubType(documentSubType);
});

Then("The Ocrevus Start Form - {string} Page should be displayed", async ({ receivedDocumentPage }, page: string) => {
  await receivedDocumentPage.verifyPatientInformationPageDisplayed(page);
});

Then("Verify Patient Search component is displayed", async ({ receivedDocumentPage }) => {
  await receivedDocumentPage.verifyPatientSearchComponentDisplayed();
});

Then("Verify all {string} fields are displayed", async ({ receivedDocumentPage }, page: string) => {
  await receivedDocumentPage.verifyFieldsDisplayed(page);
});

When("User clicks Next button", async ({ receivedDocumentPage }) => {
  await receivedDocumentPage.clickNextButton();
});

Then("Verify all {string} field error messages are displayed", async ({ receivedDocumentPage }, page: string) => {
  await receivedDocumentPage.verifyRequiredFieldErrorMessagesDisplayed(page);
});

Then(
  "Verify user navigates to Step {string} - {string} page",
  async ({ receivedDocumentPage }, pageNum: string, page: string) => {
    await receivedDocumentPage.verifyPatientInformationPageDisplayed(page);
  }
);

Then("Verify {string} picklist values are displayed", async ({ receivedDocumentPage }, picklist: string) => {
  await receivedDocumentPage.verifyPickListValuesDisplayed(picklist);
});

Then("Verify all Insurance Information fields are displayed", async ({ receivedDocumentPage }) => {
  await receivedDocumentPage.verifyInsuranceInformationFieldsDisplayed();
});

Then("Verify Insurance Information section headers are displayed", async ({ receivedDocumentPage }) => {
  await receivedDocumentPage.verifySectionHeadersDisplayed();
});

When("User selects {string} checkbox", async ({ receivedDocumentPage }, checkboxValue) => {
  await receivedDocumentPage.selectCheckbox(checkboxValue);
});

Then("Verify Site Of Treatment Search component is displayed", async ({ receivedDocumentPage }) => {
  await receivedDocumentPage.verifySiteOfTreatmentSearchComponentDisplayed();
});

Then("Verify {string} fields are Read-Only", async ({ receivedDocumentPage }, page: string) => {
  await receivedDocumentPage.verifyFieldsAreReadOnly(page);
});

When("User clicks Submit button", async ({ receivedDocumentPage }) => {
  await receivedDocumentPage.clickSubmitButton();
});

Then("Verify Enrollment Submitted confirmation message is displayed", async ({ receivedDocumentPage }) => {
  await receivedDocumentPage.verifyEnrollmentSubmittedMessageDisplayed();
});

When("User fills {string}", async ({ receivedDocumentPage }, page: string) => {
  await receivedDocumentPage.fillFormSection(page);
});

Then("User verifies treatment site fields based on Shipment To value", async ({ receivedDocumentPage }) => {
  await receivedDocumentPage.verifyConditionalTreatmentSiteDisplay();
});

Then("Verify Enrollment GPF Submitted confirmation message is displayed", async ({ receivedDocumentPage }) => {
  await receivedDocumentPage.verifyEnrollmentGPFSubmittedMessageDisplayed();
});

Then("Verify Consent Form Submitted confirmation message is displayed", async ({ receivedDocumentPage }) => {
  await receivedDocumentPage.verifyConsentFormSubmittedMessageDisplayed();
});

Then("Verify Diagnosis Information fields are displayed", async ({ receivedDocumentPage }) => {
  await receivedDocumentPage.verifyDiagnosisTreatmentFields();
});

When("User searches for the enrolled patient record and opens it", async ({ accountsPage }) => {
  await accountsPage.searchAndOpenEnrolledPatientRecord();
});

Then("User verifies the enrolled patient record is opened", async ({ accountsPage }) => {
  await accountsPage.verifyEnrolledPatientRecordIsOpened();
});

Then("User verifies the Patient Information details on the Account record", async ({ accountsPage }) => {
  await accountsPage.verifyPatientDetailsAgainstEnrolledPatientData();
});

Then(
  "User verifies the Patient Information details on the Account record excluding Household Size and Annual Household Income",
  async ({ accountsPage }) => {
    await accountsPage.verifyPatientDetailsExceptHouseholdSizeAndAnnualIncome();
  }
);

Then(
  "verify Contact Point Phone records are created and visible in the Phones related list",
  async ({ accountsPage }) => {
    await accountsPage.verifyPhoneRecords();
  }
);

Then(
  "verify GPF Contact Point Phone records are created and visible in the Phones related list",
  async ({ accountsPage }) => {
    await accountsPage.verifyGPFPhoneRecords();
  }
);

Then(
  "verify Contact Point Email record is created and visible in the Emails related list",
  async ({ accountsPage }) => {
    await accountsPage.verifyEmailRecords();
  }
);

Then(
  "verify Contact Point Address record is created and visible in the Address related list",
  async ({ accountsPage }) => {
    await accountsPage.verifyContactPointAddressRecords();
  }
);

Then("verify Phone records are not created", async ({ accountsPage }) => {
  await accountsPage.verifyPhoneRecordsNotCreated();
});

Then("verify Email records are not created", async ({ accountsPage }) => {
  await accountsPage.verifyEmailRecordsNotCreated();
});

Then("verify Contact Point Address records are not created", async ({ accountsPage }) => {
  await accountsPage.verifyContactPointAddressRecordsNotCreated();
});
