import { Given, When, Then } from "../fixtures.js";
import { DataTable } from "@cucumber/cucumber";

When(
  "Select {string} from naviagtion Hamberger Menu",
  async ({ patientAccountFormPage }, menuoption: string) => {
    await patientAccountFormPage.selectOptionFromMenu(menuoption);
  },
);
When(
  "Select New and Select {string} Checkbox",
  async ({ patientAccountFormPage }, servicetype: string) => {
    await patientAccountFormPage.selectAccountType(servicetype);
  },
);
Then(
  "Select status {string}",
  async ({ patientAccountFormPage }, statusValue: string) => {
    await patientAccountFormPage.selectPatientStatus(statusValue);
  },
);
Then("Click on Save", async ({ patientAccountFormPage }) => {
  await patientAccountFormPage.clickOnSave();
});
Then("Validate the created Account", async ({ patientAccountFormPage }) => {
  await patientAccountFormPage.validatePatientName();
});
Then("Provide the patient details", async ({ patientAccountFormPage }) => {
  await patientAccountFormPage.providePatientData();
});
When(
  "Select New from Authorization Form Consent",
  async ({ patientAccountFormPage }) => {
    await patientAccountFormPage.selectNewAuthorizationFormConsents();
  },
);
When(
  "Select consent type {string}",
  async ({ patientAccountFormPage }, consent: string) => {
    await patientAccountFormPage.selectConsentType(consent);
  },
);
Then(
  "Provide Authorization Form Consent details and click Save",
  async ({ patientAccountFormPage }) => {
    await patientAccountFormPage.provideAuthorizationFormDetails();
  },
);
When(
  "Select New Provide Care Program Enrolle details and Validate the created Care Program Enrolle",
  async ({ patientAccountFormPage }) => {
    await patientAccountFormPage.provideCareProgramEnrolleesData();
  },
);
When(
  "Select Authorization Form as {string}",
  async ({ patientAccountFormPage }, authorization: string) => {
    await patientAccountFormPage.selectAuthorizationForm(authorization);
  },
);
When(
  "Select Authorization Form Text as {string}",
  async ({ patientAccountFormPage }, authorizationText: string) => {
    await patientAccountFormPage.selectAuthorizationFormText(authorizationText);
  },
);
When(
  "provide Authorization Form deatils and Click on Save",
  async ({ patientAccountFormPage }) => {
    await patientAccountFormPage.provideAuthorizationFormDetails();
  },
);
When(
  "Create and Validate Authorization Form Consent with below details",
  async ({ patientAccountFormPage }, dataTable) => {
    const records = dataTable.hashes();
    for (let i = 0; i < records.length; i++) {
      await patientAccountFormPage.createAuthorizationFormConsent(
        records[i].ConsentType,
        records[i].AuthorizationForm,
        records[i].AuthorizationFormText,
      );
      await patientAccountFormPage.validatePatientAuthorizationForm(
        records[i].ConsentType,
        records[i].AuthorizationForm,
        records[i].AuthorizationFormText,
      );
    }
  },
);
When("Select New", async ({ patientAccountFormPage }) => {
  await patientAccountFormPage.selectNewAuthorizationFormConsents();
});
Then(
  "Click Save and validate mandatory field errors",
  async ({ patientAccountFormPage }) => {
    await patientAccountFormPage.validateMandatoryFieldErrors();
  },
);
When(
  "Create new consent with the already existing data",
  async ({ patientAccountFormPage }, dataTable) => {
    const records = dataTable.hashes();
    for (let i = 0; i < records.length; i++) {
      await patientAccountFormPage.createAuthorizationFormConsent(
        records[i].ConsentType,
        records[i].AuthorizationForm,
        records[i].AuthorizationFormText,
      );
      await patientAccountFormPage.validatePatientAuthorizationForm(
        records[i].ConsentType,
        records[i].AuthorizationForm,
        records[i].AuthorizationFormText,
      );
    }
  },
);
Then(
  "Validate the existing Consent Status and Consent Expiry Date",
  async ({ patientAccountFormPage }) => {
    await patientAccountFormPage.validateExistingConsentDetails();
  },
);
When(
  "Go to {string} Tab",
  async ({ patientAccountFormPage }, tabValue: string) => {
    await patientAccountFormPage.selectTab(tabValue);
  },
);
When(
  "Go to Preferences and add the preferences details",
  async ({ patientAccountFormPage }) => {
    await patientAccountFormPage.updateAccountPreferences("PREFERENCES1");
  },
);
Then(
  "Go to Care Program Enrolle each row and validate the added prefrences details",
  async ({ patientAccountFormPage }) => {
    await patientAccountFormPage.validateAccountPreferences("PREFERENCES1");
  },
);
When(
  "Go to Preferences and update all the preferences details",
  async ({ patientAccountFormPage }) => {
    await patientAccountFormPage.updateAccountPreferences("PREFERENCES2");
  },
);
Then(
  "Go to Care Program Enrolle each row and validate the updated prefrences details",
  async ({ patientAccountFormPage }) => {
    await patientAccountFormPage.validateAccountPreferences("PREFERENCES2");
  },
);
Then(
  "validate the added prefrences details",
  async ({ patientAccountFormPage }) => {
    await patientAccountFormPage.validateAccountPreferences("PREFERENCES1");
  },
);
Then(
  "validate the updated prefrences details",
  async ({ patientAccountFormPage }) => {
    await patientAccountFormPage.validateAccountPreferences("PREFERENCES2");
  },
);
When(
  "Go to Setup and Login As {string}",
  async ({ commonPage, patientAccountFormPage }, userName: string) => {
    const setupPage = await commonPage.clickOnSetupIconAndLoginAs(userName);
    patientAccountFormPage.setPage(commonPage["page"]);
  },
);
Then(
  "Go to Care Program Enrolle each row and validate the prefrences are visible",
  async ({ patientAccountFormPage }) => {
    await patientAccountFormPage.validateAllCareProgramPreferences();
  },
);
When(
  "Create Authorization Form Consent with status and validate with below details",
  async ({ patientAccountFormPage }, dataTable) => {
    const records = dataTable.hashes();
    for (let i = 0; i < records.length; i++) {
      await patientAccountFormPage.createAuthorizationFormConsentWithStatus(
        records[i].ConsentType,
        records[i].AuthorizationForm,
        records[i].AuthorizationFormText,
        records[i].Status,
      );
      await patientAccountFormPage.validatePatientAuthorizationFormWithStatus(
        records[i].ConsentType,
        records[i].AuthorizationForm,
        records[i].AuthorizationFormText,
        records[i].Status,
      );
    }
  },
);
Then(
  "Validate consent are in sorted order",
  async ({ patientAccountFormPage }) => {
    await patientAccountFormPage.validateConsentStatusOrder();
  },
);
