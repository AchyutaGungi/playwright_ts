import { When, Then } from "../fixtures.js";
import fs from "fs";
import path from "path";
import { ApiUtil } from "../../utils/api/ApiUtil.js";
import { ApiValidationUtil } from "../../utils/api/ApiValidationUtil.js";

When(
  "User sends {string} request to {string} using payload {string} using auth {string}",
  async (
    { request, $testInfo, scenarioContext },
    requestType: string,
    serviceName: string,
    payloadFile: string,
    authType: string
  ) => {
    const apiUtil = new ApiUtil(request);
    const endpoints = JSON.parse(
      fs.readFileSync(path.join(process.cwd(), "testdata", "Tailormed", "apiEndpoints.json"), "utf-8")
    );
    //Get API EndPoint
    const apiUrl = endpoints[serviceName];
    if (!apiUrl) {
      throw new Error(`No URL configured for service : ${serviceName}`);
    }
    //Get Payload
    const payload = JSON.parse(
      fs.readFileSync(path.join(process.cwd(), "testdata", "TailorMed", "Payloads", `${payloadFile}.json`), "utf-8")
    );
    //Get Authorization
    let authorization = "";
    switch (authType.toUpperCase()) {
      case "BASIC":
        authorization = apiUtil.getBasicAuth(process.env.API_USERNAME!, process.env.API_PASSWORD!);
        break;
      case "BEARER":
        authorization = apiUtil.getBearerToken(process.env.ACCESS_TOKEN!);
        break;
      case "NONE":
        authorization = "";
        break;
      default:
        throw new Error(`Unsupported Auth Type : ${authType}`);
    }
    //Get Response
    const response = await apiUtil.sendRequest({
      method: requestType,
      url: apiUrl,
      payload,
      authorization,
    });
    const responseJson = await response.json();
    scenarioContext.set("apiResponse", response);
    console.log(`Response Status : ${response.status()}`);
    console.log(JSON.stringify(responseJson, null, 2));
    await $testInfo.attach("API Response", {
      body: JSON.stringify(responseJson, null, 2),
      contentType: "application/json",
    });
  }
);

Then("Response status code should be {string}", async ({ scenarioContext }, expectedStatusCode: string) => {
  const response = scenarioContext.get("apiResponse");
  await ApiValidationUtil.validateStatusCode(response, Number(expectedStatusCode));
});

Then(
  "Response should contain field {string} with value {string}",
  async ({ scenarioContext }, fieldName: string, expectedValue: string) => {
    const response = scenarioContext.get("apiResponse");
    await ApiValidationUtil.validateField(response, fieldName, expectedValue);
  }
);

Then("Response should contain field", async ({ scenarioContext }, dataTable) => {
  const expectedTexts = dataTable.raw().flat();
  const response = scenarioContext.get("apiResponse");
  for (const expectedText of expectedTexts) {
    await ApiValidationUtil.validateResponseContains(response, expectedText);
  }
});

Then("Response should contain the following field values", async ({ scenarioContext }, dataTable) => {
  const response = scenarioContext.get("apiResponse");
  const validations = dataTable.hashes();
  for (const row of validations) {
    await ApiValidationUtil.validateField(response, row.Field, row.Value);
  }
});
