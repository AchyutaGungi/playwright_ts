@getassitanceapi @api
Feature: Validate Get Assitance API

  Scenario: Verify Get Assistance API Post Call
    When User sends "POST" request to "GetAssitanceDetailsAPI" using payload "GetAssitanceDetailsPayload" using auth "Basic"
    Then Response status code should be "200"
    And Response should contain the following field values
      | Field                                                            | Value    |
      | payload.assistanceProgramsGPF.0.programDetails.eligibilityStatus | Approved |
      | payload.drugName                                                 | Hemlibra |
    And Response should contain field
      | eligibilityStatus |
