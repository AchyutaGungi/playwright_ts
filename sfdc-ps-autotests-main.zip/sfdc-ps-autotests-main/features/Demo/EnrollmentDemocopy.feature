#@enroll
Feature: Enrollment Feature

Scenario: Valid Enrollment for Patient
    #Given User launches salesforce application
    #When User enters username and password "Admin"
    Then User should login successfully
    When Select "Enroll Patient" from naviagtion menu dropdown
    Then Provide the patient data
    And Click on Enroll  
    And Set product and Diagonosiscode
    And Select "Benefits Investigation/Prior Authorization" Checkbox
    #And Select "Patient Foundation" Checkbox
    Then Click on Next
    And Set Patient address
    And Set Payer Name
    And Set Prescriber data
    And Set Enrollment data
    And Click on Submit Enrollment