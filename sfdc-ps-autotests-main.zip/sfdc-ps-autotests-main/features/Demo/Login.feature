@loginfeature
Feature: Login

Scenario: Valid Login
    Given User launches salesforce application
    When User enters username and password "Admin"
    #Then User should login successfully
    Then User Validate Privacy Page