@enrollPatientConsent @regression
Feature: Patient Consent Form Feature

  Scenario: Validate Fields, Picklist Values, and Required Field Error Messages Across Patient Consent Form Pages (Steps 1-4)
    Given User launches life sciences cloud salesforce application
    #When  User enters username and password "YosemiteAdmin"
    When Click on App Launcher
    And Search "PEP" from App Launcher and Select that Product
    Then User should login life sciences cloud salesforce successfully
    When Click on App Launcher
    And Search "Received Documents" from App Launcher and Select that Product
    And Click on New Button
    And User creates a new Received Document with valid details
    And Click on 'Related'
    And User uploads document "Patient Consent Form.pdf"
    And Click on 'Document Viewer'
    And User selects classification as "Consent Form"
    And Click on Next Button
    Then The Ocrevus Start Form - "Patient Information" Page should be displayed
    And Verify Patient Search component is displayed
    And Verify all "Patient Information" fields are displayed
    And Verify "Preferred Language" picklist values are displayed
    And Verify "Alternate Contact Relationship" picklist values are displayed
    When User clicks Next button
    Then Verify all "Patient required" field error messages are displayed
    When User fills "Patient Information"
    And User clicks Next button
    Then Verify user navigates to Step "2" - "Financial Eligibility" page
    And Verify all "Financial Eligibility" fields are displayed
    When User fills "Financial Eligibility"
    And User clicks Next button
    Then Verify user navigates to Step "3" - "Additional Services" page
    And Verify all "Additional Services" fields are displayed
    When User fills "Additional Services"
    And User clicks Next button
    Then Verify user navigates to Step "4" - "Signature" page
    And Verify all "Signature" fields are displayed
    When User fills "Signature"
    And User clicks Submit button
    Then Verify Consent Form Submitted confirmation message is displayed