@enrollOcrevus @regression
Feature: Enrollment OcrevusStart Feature

  Scenario: Validate Fields, Picklist Values, and Required Field Error Messages Across Enrollment Ocrevus Start Form Pages (Steps 1-6)
    Given User launches life sciences cloud salesforce application
    #When  User enters username and password "YosemiteAdmin"
    When Click on App Launcher
    And Search "PEP" from App Launcher and Select that Product
    Then User should login life sciences cloud salesforce successfully
    When Click on App Launcher
    And Search "Received Documents" from App Launcher and Select that Product
    And Click on New Button
    And User creates a new Received Document with valid details
    And Click on 'Related'
    And User uploads document "OCREVUS Start Form.pdf"
    And Click on 'Document Viewer'
    And User selects classification as "Enrollment Form"
    And User selects Document Sub-Type as "Ocrevus Start Form"
    And Click on Next Button
    Then The Ocrevus Start Form - "Patient Information" Page should be displayed
    And Verify Patient Search component is displayed
    And Verify all "Patient Information" fields are displayed
    And Verify "Patient State" picklist values are displayed
    And Verify "Preferred Language" picklist values are displayed
    And Verify "Gender" picklist values are displayed
    And Verify "Alternate Contact Relationship" picklist values are displayed
    When User clicks Next button
    Then Verify all "Patient required" field error messages are displayed
    When User fills "Patient Information"
    And User clicks Next button
    Then Verify user navigates to Step "2" - "Insurance Information" page
    And Verify all "Insurance Information" fields are displayed
    And Verify Insurance Information section headers are displayed
    # And Verify all Insurance Information fields are displayed
    And Verify "Insured?" picklist values are displayed
    And Verify "Prior Authorization in Place?" picklist values are displayed
    When User fills "Insurance Information"
    And User clicks Next button
    Then Verify user navigates to Step "3" - "Prescriber Information" page
    And Verify all "Prescriber Information" fields are displayed
    When User fills "Prescriber Information"
    And User clicks Next button
    Then Verify user navigates to Step "4" - "Diagnosis & Treatment" page
    And Verify Diagnosis Information fields are displayed
    When User clicks Next button
    Then Verify all "Diagnosis & Treatment required" field error messages are displayed
    When User selects "OCREVUS IV infusion" checkbox
    When User clicks Next button
    Then Verify user navigates to Step "5" - "Treatment Site Location" page
    And Verify Site Of Treatment Search component is displayed
    And Verify all "Treatment Site Location" fields are displayed
    When User fills "Treatment Site Location"
    When User clicks Next button
    Then Verify user navigates to Step "6" - "Starter Rx" page
    And Verify all "Starter Rx" fields are displayed
    And Verify "Starter Rx" fields are Read-Only
    When User clicks Submit button
    Then Verify Enrollment Submitted confirmation message is displayed
    