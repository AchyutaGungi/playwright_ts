@enrollGPF @regression
Feature:Genentech Patient Foundation Form Feature

  Scenario: Validate Fields, Picklist Values, and Required Field Error Messages Across Genentech Patient Foundation Form Pages (Steps 1-5)
    Given User launches life sciences cloud salesforce application
    #When  User enters username and password "YosemiteAdmin"
    When Click on App Launcher
    And Search "PEP" from App Launcher and Select that Product
    Then User should login life sciences cloud salesforce successfully
    When Click on App Launcher
    And Search "Received Documents" from App Launcher and Select that Product
    And Click on New Button
    And User creates a new Received Document with valid details
    And Click on 'Related'
    And User uploads document "OCREVUS Start Form.pdf"
    And Click on 'Document Viewer'
    And User selects classification as "Enrollment Form"
    And User selects Document Sub-Type as "Genentech Patient Foundation Form"
    And Click on Next Button
    Then The Ocrevus Start Form - "Patient Information" Page should be displayed
    And Verify Patient Search component is displayed
    And Verify all "Patient Information" fields are displayed
    And Verify "Preferred Language" picklist values are displayed
    And Verify "Gender" picklist values are displayed
    And Verify "Phone Type" picklist values are displayed
    When User clicks Next button
    When User fills "Patient Information"
    And User clicks Next button
    Then Verify user navigates to Step "2" - "Insurance Information" page
    And Verify all "Insurance Information" fields are displayed
    And Verify "Has Insurance?" picklist values are displayed
    And Verify "Coverage Denied For Medication?" picklist values are displayed
    And Verify "Insurance Cards Attached?" picklist values are displayed
    And Verify "Denial Letters / Documents Attached?" picklist values are displayed
    When User fills "Insurance Information"
    And User clicks Next button
    Then Verify user navigates to Step "3" - "Diagnosis & Treatment" page
    And Verify Diagnosis Information fields are displayed
    And Verify "Primary Diagnosis Code" picklist values are displayed
    And Verify "Has Patient Started Therapy?" picklist values are displayed
    When User clicks Next button
    Then Verify all "Diagnosis & Treatment required" field error messages are displayed
    When User selects "Ocrevus" checkbox
    When User fills "Diagnosis & Treatment required"
    And User clicks Next button
    Then Verify user navigates to Step "4" - "Shipment Information" page
    And Verify "Shipment Option" picklist values are displayed
    And Verify "Shipment To" picklist values are displayed
    And User verifies treatment site fields based on Shipment To value
    When User fills "Shipment Information"
    And User clicks Next button
    Then Verify user navigates to Step "5" - "Prescriber Information" page
    And Verify all "Prescriber Information" fields are displayed
    When User fills "Prescriber Information"
    And User clicks Submit button
    Then Verify Enrollment GPF Submitted confirmation message is displayed
