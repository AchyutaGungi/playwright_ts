Feature:Enrollment Engine OSF Positive Scenarios
  Validates successful processing of Ocrevus Start Form
  and creation of enrollment records.

Background:
    Given User launches life sciences cloud salesforce application
    #When  User enters username and password "YosemiteAdmin"
    When Click on App Launcher
    And Search "PEP" from App Launcher and Select that Product
    Then User should login life sciences cloud salesforce successfully
    When Click on App Launcher
    And Search "Received Documents" from App Launcher and Select that Product
    And Click on New Button
    And User creates a new Received Document with valid details
    And Click on 'Related'
    And User uploads document "OCREVUS Start Form.pdf"
    And Click on 'Document Viewer'
    And User selects classification as "Enrollment Form"
    And User selects Document Sub-Type as "Ocrevus Start Form"
    And Click on Next Button
    Then The Ocrevus Start Form - "Patient Information" Page should be displayed
    When User fills "Patient Information"
    And User clicks Next button
    Then Verify user navigates to Step "2" - "Insurance Information" page
    When User fills "Insurance Information"
    And User clicks Next button
    Then Verify user navigates to Step "3" - "Prescriber Information" page
    And User clicks Next button
    Then Verify user navigates to Step "4" - "Diagnosis & Treatment" page
    When User selects "OCREVUS IV infusion" checkbox
    When User clicks Next button
    Then Verify user navigates to Step "5" - "Treatment Site Location" page
    When User clicks Next button
    Then Verify user navigates to Step "6" - "Starter Rx" page
    When User clicks Submit button
    Then Verify Enrollment Submitted confirmation message is displayed

@PCLSC-314_AC1 @regression
Scenario: Verify Person Account and Contact Point records creation for new patient
   When Click on App Launcher
   And Search "Accounts" from App Launcher and Select that Product
   And User searches for the enrolled patient record and opens it
   Then User verifies the enrolled patient record is opened
   When Click on 'Details'
   And User verifies the Patient Information details on the Account record
   When Click on 'Related'
   Then verify Contact Point Phone records are created and visible in the Phones related list
   And verify Contact Point Email record is created and visible in the Emails related list
   And verify Contact Point Address record is created and visible in the Address related list