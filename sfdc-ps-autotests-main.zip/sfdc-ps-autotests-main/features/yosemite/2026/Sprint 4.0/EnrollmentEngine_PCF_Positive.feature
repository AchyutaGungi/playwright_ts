Feature:Enrollment Engine PCF Positive Scenarios
  Validates successful processing of PCF
  and creation of enrollment records.

Background:
   Given User launches life sciences cloud salesforce application
    #When  User enters username and password "YosemiteAdmin"
    When Click on App Launcher
    And Search "PEP" from App Launcher and Select that Product
    Then User should login life sciences cloud salesforce successfully
    When Click on App Launcher
    And Search "Received Documents" from App Launcher and Select that Product
    And Click on New Button
    And User creates a new Received Document with valid details
    And Click on 'Related'
    And User uploads document "Patient Consent Form.pdf"
    And Click on 'Document Viewer'
    And User selects classification as "Consent Form"
    And Click on Next Button
    Then The Ocrevus Start Form - "Patient Information" Page should be displayed
    When User fills "Patient Information"
    And User clicks Next button
    Then Verify user navigates to Step "2" - "Financial Eligibility" page
    When User fills "Financial Eligibility"
    And User clicks Next button
    Then Verify user navigates to Step "3" - "Additional Services" page
    And User clicks Next button
    Then Verify user navigates to Step "4" - "Signature" page
    When User fills "Signature"
    And User clicks Submit button
    Then Verify Consent Form Submitted confirmation message is displayed

@PCLSC-314_AC3 @regression
Scenario: Verify Person Account and Contact Point records creation for new patient
   When Click on App Launcher
   And Search "Accounts" from App Launcher and Select that Product
   And User searches for the enrolled patient record and opens it
   Then User verifies the enrolled patient record is opened
   When Click on 'Details'
   Then User verifies the Patient Information details on the Account record
   When Click on 'Related'
   Then verify Contact Point Phone records are created and visible in the Phones related list
   And verify Contact Point Email record is created and visible in the Emails related list
  