@PatientForms
Feature: Patient Forms Feature

Scenario: Create Patient Account , Care Program Enrolle and Authorization Form Consent
    Given User launches salesforce application
    #When User enters username and password "Admin"
   # Then User should login successfully
    When Click on App Launcher
    When Select "PEP" from naviagtion Hamberger Menu
    When Click on App Launcher
    When Select "Accounts" from naviagtion Hamberger Menu
    When Select New and Select "Patient" Checkbox
    Then Provide the patient details
    And  Select status "Active"
    Then Click on Save 
    And  Validate the created Account
    When Select New Provide Care Program Enrolle details and Validate the created Care Program Enrolle  
    When Create and Validate Authorization Form Consent with below details
  | ConsentType           | AuthorizationForm  | AuthorizationFormText     |
  | Program Authorization | OCREVUS Start Form | OCREVUS Start Form Text |
  | HIPAA Authorization | Patient Consent Form | Patient Consent Form Text |
   When Select New
   Then Click Save and validate mandatory field errors