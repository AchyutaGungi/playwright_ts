@PCLSC-157 @Regression
Feature: New consent captured creates a new record if consent already exists on file

Scenario: Create Patient Account, Create Multiple Authorization Form Consent, Create New Consent with already  existing consent and Validate the Status & Expiry Date
    Given User launches salesforce application
    #When User enters username and password "Admin"
   # Then User should login successfully
    When Click on App Launcher
    When Select "PEP" from naviagtion Hamberger Menu
    When Click on App Launcher
    When Select "Accounts" from naviagtion Hamberger Menu
    When Select New and Select "Patient" Checkbox
    Then Provide the patient details
    And  Select status "Active"
    Then Click on Save 
    And  Validate the created Account
    When Create and Validate Authorization Form Consent with below details
  | ConsentType             | AuthorizationForm  | AuthorizationFormText     |
  | Program Authorization | OCREVUS Start Form | OCREVUS Start Form Text |
  | HIPAA Authorization | Patient Consent Form | Patient Consent Form Text |
  |HCP/Provider Consent | FENEBRUTINIB Start Form | FENEBRUTINIB Start Form Text |
  |Copay Program Enrollment | Universal Consent Form | 	Universal Consent Form Text |
   When Create new consent with the already existing data
  | ConsentType             | AuthorizationForm  | AuthorizationFormText     |
  |Program Authorization | OCREVUS Start Form | OCREVUS Start Form Text |
   Then Validate the existing Consent Status and Consent Expiry Date
  
   