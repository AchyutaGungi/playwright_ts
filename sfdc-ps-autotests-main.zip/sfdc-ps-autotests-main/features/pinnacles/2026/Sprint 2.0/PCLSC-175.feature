@PCLSC-175 @Regression
Feature: CareGiver Communication and Channel Preference capture

Scenario: Create Alternate Contact, Create Care Program Enrolle, Add & Update Preferences then validate
    Given User launches salesforce application
    #When User enters username and password "Admin"
   # Then User should login successfully
   When Go to Setup and Login As "Patient Navigator 01"
    When Click on App Launcher
    When Select "PEP" from naviagtion Hamberger Menu
    When Click on App Launcher
    When Select "Accounts" from naviagtion Hamberger Menu
    When Select New and Select "Alternate Contact" Checkbox
    Then Provide the patient details
    Then Click on Save 
    And  Validate the created Account 
    When Go to "Details" Tab
    And Go to Preferences and add the preferences details
    Then validate the added prefrences details
    And Go to Preferences and update all the preferences details
    Then validate the updated prefrences details





 

