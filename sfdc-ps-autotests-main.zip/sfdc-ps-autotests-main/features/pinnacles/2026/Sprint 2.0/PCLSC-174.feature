@PCLSC-174 @Regression
Feature: Patient Communication and Channel Preference capture

Scenario: Create Patient Account, Create Care Program Enrolle, Add & Update Preferences then validate
    Given User launches salesforce application
    #When User enters username and password "Admin"
   # Then User should login successfully
    When Click on App Launcher
    When Select "PEP" from naviagtion Hamberger Menu
    When Click on App Launcher
    When Select "Accounts" from naviagtion Hamberger Menu
    When Select New and Select "Patient" Checkbox
    Then Provide the patient details
    And  Select status "Active"
    Then Click on Save 
    And  Validate the created Account
    When Go to "Details" Tab
    And Go to Preferences and add the preferences details
    Then validate the added prefrences details
    # When Go to "Related" Tab
    # Then Go to Care Program Enrolle each row and validate the added prefrences details
    # When Go to "Details" Tab
    And Go to Preferences and update all the preferences details
    # When Go to "Related" Tab
    # Then Go to Care Program Enrolle each row and validate the updated prefrences details
    Then validate the updated prefrences details





 

