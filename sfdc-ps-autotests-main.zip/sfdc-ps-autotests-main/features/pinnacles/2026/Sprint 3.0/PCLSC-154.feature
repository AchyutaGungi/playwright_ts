@PCLSC-154 @Regression
Feature: CView and Manage consent records on Patient Account

@AC1 @Regression
Scenario: Create Patient Account, Create Authorization Form Consents and Validate
    Given User launches salesforce application
    #When User enters username and password "Admin"
   # Then User should login successfully
     When Go to Setup and Login As "Patient Navigator 01"
    When Click on App Launcher
    When Select "PEP" from naviagtion Hamberger Menu
    When Click on App Launcher
    When Select "Accounts" from naviagtion Hamberger Menu
    When Select New and Select "Patient" Checkbox
    Then Provide the patient details
    And  Select status "Active"
    Then Click on Save 
    And  Validate the created Account
    When Create and Validate Authorization Form Consent with below details
  | ConsentType             | AuthorizationForm  | AuthorizationFormText     |
  | Program Authorization | OCREVUS Start Form | OCREVUS Start Form Text |
  | HIPAA Authorization | Patient Consent Form | Patient Consent Form Text |
  |HCP/Provider Consent | FENEBRUTINIB Start Form | FENEBRUTINIB Start Form Text |
  |Copay Program Enrollment | Universal Consent Form | 	Universal Consent Form Text |

  @AC2 @AC3 @Regression
  Scenario:Create Patient Account, Create Authorization Form Consents and Sort , Validate
  Given User launches salesforce application
    #When User enters username and password "Admin"
   # Then User should login successfully
    #  When Go to Setup and Login As "Patient Navigator 01"
    When Click on App Launcher
    When Select "PEP" from naviagtion Hamberger Menu
    When Click on App Launcher
    When Select "Accounts" from naviagtion Hamberger Menu
    When Select New and Select "Patient" Checkbox
    Then Provide the patient details
    And  Select status "Active"
    Then Click on Save 
    And  Validate the created Account
    When Create Authorization Form Consent with status and validate with below details
  | ConsentType             | AuthorizationForm  | AuthorizationFormText     | Status |
  | Program Authorization | OCREVUS Start Form | OCREVUS Start Form Text | Active |
  | HIPAA Authorization | Patient Consent Form | Patient Consent Form Text | Expired |
  |HCP/Provider Consent | FENEBRUTINIB Start Form | FENEBRUTINIB Start Form Text | Revoked |
   Then Validate consent are in sorted order

