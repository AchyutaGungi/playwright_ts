@PCLSC-626 @Regression
Feature: Care Program Enrolle consent and Prefrence Management

Scenario: Create Patient Account, Create Care Program Enrolle, Add & Update Preferences then validate in created Care Program Enrolle
    Given User launches salesforce application
    #When User enters username and password "Admin"
   # Then User should login successfully
    When Click on App Launcher
    When Select "PEP" from naviagtion Hamberger Menu
    When Click on App Launcher
    When Select "Accounts" from naviagtion Hamberger Menu
    When Select New and Select "Patient" Checkbox
    Then Provide the patient details
    And  Select status "Active"
    Then Click on Save 
    And  Validate the created Account
    When Select New Provide Care Program Enrolle details and Validate the created Care Program Enrolle  
    Then Go to Care Program Enrolle each row and validate the prefrences are visible
    When Go to "Details" Tab
    And Go to Preferences and add the preferences details
    When Go to "Related" Tab
    Then Go to Care Program Enrolle each row and validate the added prefrences details
    When Go to "Details" Tab
    And Go to Preferences and update all the preferences details
    When Go to "Related" Tab
    Then Go to Care Program Enrolle each row and validate the updated prefrences details





 

